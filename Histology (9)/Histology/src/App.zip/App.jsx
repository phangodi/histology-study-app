import React, { useState } from 'react';
import { BookOpen, Layers, Zap, Network, Target, ChevronLeft, ChevronRight, Search } from 'lucide-react';

// ============================================================================
// HOW TO USE THIS TEMPLATE:
// 1. Generate slide data using the prompt: "Generate Slide XX"
// 2. Copy the JavaScript object output from Claude
// 3. Paste it into the SLIDE_DATA constant below
// 4. Repeat for multiple slides to build your study app
// ============================================================================

// PASTE YOUR GENERATED SLIDE DATA HERE
const SLIDE_DATA_70 = {
  slideNumber: "70",
  name: "Peripheral Nerve - Cross Section (HE)",
  section: "cross section",
  stain: "HE",
  
  bigPicture: "Peripheral nerve = axons wrapped in 3 protective CT layers (like CNS meninges!)",
  
  hierarchy: [
    "Axon → Fascicle → Whole Nerve",
    "↓ ENDO → PERI → EPI",
    "↓ (Pia) → (Arachnoid) → (Dura)"
  ],
  
  insideTheFascicles: [
    {
      structure: "Axon",
      description: "Tiny pink dot in center of myelin ring; carries electrical impulses along nerve fiber"
    },
    {
      structure: "Myelin sheath (negative image)",
      description: "White circular space around axon; lipid dissolved during processing creating characteristic honeycomb pattern"
    },
    {
      structure: "Schwann cell nucleus",
      description: "Elongated blue/purple nucleus at periphery of myelin ring; produces and maintains myelin sheath"
    },
    {
      structure: "Endoneurium",
      description: "Delicate pink connective tissue between individual fibers; contains capillaries and supports nerve fibers"
    },
    {
      structure: "Fibroblast nuclei",
      description: "Scattered elongated blue nuclei within endoneurium; maintain connective tissue matrix"
    }
  ],
  
  stainingInfo: {
    technique: "H&E (Hematoxylin and Eosin)",
    description: "Hematoxylin stains basophilic structures (nuclei, ribosomes, rough ER) blue/purple. Eosin stains acidophilic structures (cytoplasm, collagen, extracellular matrix) pink/red.",
    whatItStainsInThisSlide: [
      "Schwann cell nuclei → Blue/purple (elongated at periphery of myelin rings)",
      "Fibroblast nuclei (in endoneurium, perineurium, epineurium) → Blue/purple",
      "Endothelial cell nuclei (in blood vessels) → Blue/purple",
      "Connective tissue (endoneurium, perineurium, epineurium) → Pink (varying intensities)",
      "Axon cytoplasm → Pale pink (tiny dot in center of myelin ring when visible)",
      "Myelin sheath → WHITE SPACE (negative image - lipids dissolved during tissue processing)",
      "Adipocytes → WHITE SPACE (lipids removed, leaving empty cellular outlines)",
      "Perineurium → Distinct pink rim around each fascicle"
    ],
    keyEmphasis: "HE emphasizes the three-layered connective tissue organization and cellular nuclei throughout the nerve. The characteristic honeycomb pattern created by myelin spaces (white circles with pink central dots) within fascicles is the diagnostic signature feature of peripheral nerve in cross section. Lipid dissolution during histological preparation creates negative images of both myelin sheaths and adipocytes - the key is distinguishing them by size and location."
  },

  layers: [
    {
      name: "Endoneurium",
      level: "Innermost layer (Level 1)",
      wraps: "Individual nerve fiber (single axon + myelin sheath + Schwann cell)",
      composition: "Delicate loose connective tissue with reticular fibers (Type III collagen), scattered fibroblasts, capillaries (endoneurial capillaries), and extracellular fluid that bathes nerve fibers",
      appearance: "Very thin pink tissue barely visible between individual nerve fibers within a fascicle. Seen as delicate pink strands separating the white myelin spaces in the honeycomb pattern. Often difficult to visualize due to thinness.",
      contains: "Endoneurial capillaries (part of blood-nerve barrier), fibroblasts producing collagen, reticular fibers forming delicate scaffolding, tissue fluid maintaining ionic balance for nerve conduction",
      cnsEquivalent: "Pia mater (direct transition at CNS-PNS junction at nerve roots)",
      function: "Provides immediate microenvironment for individual nerve fibers, supports axon nutrition through capillary network and metabolic exchange, maintains optimal ionic balance for action potential propagation, cushions individual fibers from mechanical stress",
      quickID: "Thinnest pink layer, barely visible between individual nerve fibers inside bundles"
    },
    {
      name: "Perineurium",
      level: "Middle layer (Level 2)",
      wraps: "Fascicle (bundle of multiple nerve fibers grouped together)",
      composition: "2-6 concentric layers of specialized epithelioid perineural cells (modified fibroblasts with epithelial characteristics) connected by tight junctions (zonulae occludentes), each layer surrounded by its own basement membrane composed of Type IV collagen and laminin",
      appearance: "Distinct pink rim encircling each fascicle, appearing as a smooth, continuous boundary. More prominent and easily visible than endoneurium, creates clear fascicle borders. Appears as a condensed pink line that sharply demarcates fascicle boundaries.",
      contains: "Epithelioid perineural cells with tight junctions forming selective barrier, basement membranes surrounding each cellular layer, occasional fibroblasts between layers, perineurial space containing small amount of fluid",
      cnsEquivalent: "Arachnoid mater (transition at nerve roots)",
      function: "Forms the critical blood-nerve barrier by controlling diffusion of substances into and out of fascicles through tight junctions, maintains stable microenvironment essential for proper nerve conduction, protects against mechanical stress and prevents spread of infection between fascicles, regulates ionic composition within fascicle",
      quickID: "Distinct pink rim surrounding each honeycomb bundle - the fascicle border you can actually see"
    },
    {
      name: "Epineurium",
      level: "Outermost layer (Level 3)",
      wraps: "Entire nerve (multiple fascicles bundled together into complete nerve trunk)",
      composition: "Dense irregular connective tissue with thick collagen bundles (Type I collagen) arranged in various directions, abundant adipose tissue filling spaces between fascicles, numerous fibroblasts, blood vessels (vasa nervorum providing nerve's blood supply), lymphatic vessels for drainage, and occasional nerve fibers (nervi nervorum innervating the nerve sheaths)",
      appearance: "Thick pink connective tissue surrounding and separating fascicles throughout the nerve. Contains conspicuous large white adipocytes (much larger than myelin spaces) and visible blood vessels. Forms the outermost coat of the entire nerve and fills interfascicular spaces.",
      contains: "Vasa nervorum (blood vessels nourishing the nerve), lymphatic vessels for waste removal and immune surveillance, adipose tissue providing cushioning and energy storage, dense collagen fibers for mechanical protection, nervi nervorum (small nerves that innervate the larger nerve sheaths), fibroblasts maintaining the extracellular matrix",
      cnsEquivalent: "Dura mater (continuous transition at nerve roots where nerves enter/exit CNS)",
      function: "Provides mechanical protection against compression and stretching forces, supplies vascular support through vasa nervorum network, allows nerve mobility and flexibility through adipose tissue cushioning, binds fascicles together into unified nerve trunk, protects against infection spread from surrounding tissues",
      quickID: "Thickest layer with large white adipocytes, surrounds entire nerve and fills spaces between fascicles"
    }
  ],

  essentialStructures: [
    {
      structure: "Axon (nerve fiber center)",
      identificationTips: [
        "Appears as tiny pink dot (often just a few micrometers) in the center of each white myelin ring",
        "Contains axoplasm that stains pale pink with eosin when visible",
        "Size varies: large myelinated fibers have visible axons, small fibers may show axon as just a pinpoint",
        "Round to oval cross-sectional profile within the myelin space",
        "In high-quality sections, you may see neurofilaments within the axoplasm"
      ],
      commonMistakes: [
        {
          mistake: "Confusing the axon with the Schwann cell nucleus",
          why: "Both appear as dark structures within or near the myelin ring",
          avoid: "Axon is in the CENTER (small pink dot), Schwann nucleus is at the PERIPHERY (elongated blue structure at the edge). Schwann nucleus is larger and darker blue."
        },
        {
          mistake: "Thinking the white space is the axon",
          why: "Students expect axons to be prominent structures",
          avoid: "The white space is the MYELIN SHEATH (lipid removed), not the axon. The axon is the tiny pink dot IN THE CENTER of the white space."
        }
      ]
    },
    {
      structure: "Myelin sheath (negative image)",
      identificationTips: [
        "Appears as white circular or oval spaces arranged in honeycomb pattern within fascicles",
        "Creates the diagnostic honeycomb appearance - this is the hallmark of peripheral nerve in cross section",
        "Uniform size within a given nerve (5-15 μm diameter typically)",
        "Each white ring should have a tiny pink dot (axon) in center and often a blue nucleus (Schwann cell) at periphery",
        "The WHITE color is due to lipid dissolution during tissue processing - remember this is a NEGATIVE IMAGE",
        "In high-power magnification, you may see a thin pink line (neurolemma/Schwann cell cytoplasm) surrounding the white space"
      ],
      commonMistakes: [
        {
          mistake: "Expecting to see black or pink myelin in HE sections",
          why: "Students confuse HE staining with osmium tetroxide (OsO₄) staining",
          avoid: "In HE, myelin appears WHITE (negative image, lipids dissolved). In OsO₄ stain (Slide 72), myelin appears BLACK. Never expect pink myelin in any stain - it's either white (HE) or black (OsO₄)."
        },
        {
          mistake: "Confusing myelin spaces with adipocytes",
          why: "Both appear as white spaces in HE sections",
          avoid: "MYELIN: small (5-15 μm), uniform, INSIDE fascicles, honeycomb pattern, has central axon dot. ADIPOCYTES: large (50-150 μm, 3× bigger), variable sizes, OUTSIDE fascicles in epineurium, no central structure."
        },
        {
          mistake: "Missing the honeycomb pattern entirely",
          why: "Scanning at low power without focusing on fascicle interiors",
          avoid: "Always examine INSIDE the fascicles (areas bounded by pink perineurial rims). The honeycomb is the diagnostic feature!"
        }
      ]
    },
    {
      structure: "Schwann cell nucleus",
      identificationTips: [
        "Elongated, flattened blue/purple nucleus located at the PERIPHERY of each myelin ring",
        "Appears as a dark crescent or cigar-shaped structure pressed against the inner edge of the Schwann cell",
        "Each myelinated fiber has ONE Schwann cell in any given cross-section (though multiple Schwann cells wrap the fiber along its length)",
        "Heterochromatic (dark-staining) nucleus with condensed chromatin",
        "May not be visible in every myelin ring in a single section (depends on plane of section)"
      ],
      commonMistakes: [
        {
          mistake: "Thinking every myelin ring must show a Schwann nucleus",
          why: "The nucleus is 3D and may not be in the plane of this particular section",
          avoid: "It's normal to see some myelin rings without visible nuclei. Look for nuclei at the periphery of SOME rings to confirm Schwann cells."
        },
        {
          mistake: "Confusing Schwann nuclei with fibroblast nuclei in endoneurium",
          why: "Both are elongated and basophilic",
          avoid: "Schwann nuclei are specifically at the PERIPHERY of myelin rings. Fibroblast nuclei are scattered between nerve fibers in the endoneurium, not associated with specific myelin rings."
        }
      ]
    },
    {
      structure: "Fascicle (nerve fiber bundle)",
      identificationTips: [
        "Distinct bundle of nerve fibers surrounded by pink perineurial rim",
        "Contains the diagnostic honeycomb pattern of myelin spaces",
        "Variable sizes - nerves typically contain multiple fascicles of different sizes",
        "Each fascicle is a self-contained unit with its own perineurial barrier",
        "The interior shows densely packed myelinated fibers creating the characteristic honeycomb appearance"
      ],
      commonMistakes: [
        {
          mistake: "Thinking the entire nerve is one fascicle",
          why: "Students miss the individual perineurial boundaries",
          avoid: "Look for multiple pink rims (perineurium) dividing the nerve into separate fascicles. Each pink rim = one fascicle boundary."
        },
        {
          mistake: "Confusing a single fascicle with the whole nerve",
          why: "In some sections, only one fascicle may be prominent",
          avoid: "The whole nerve = epineurium + all fascicles. One fascicle = perineurium + nerve fibers. Look at low power to see the big picture."
        }
      ]
    },
    {
      structure: "Perineurium (pink rim)",
      identificationTips: [
        "Distinct, smooth pink rim that completely encircles each fascicle",
        "More prominent than endoneurium - this is your anchor structure for identification",
        "Appears as a condensed pink line clearly demarcating fascicle boundaries",
        "Multiple concentric layers may be visible in high-power views (2-6 layers)",
        "Continuous around entire fascicle with no gaps"
      ],
      commonMistakes: [
        {
          mistake: "Confusing perineurium with epineurium",
          why: "Both are pink connective tissue",
          avoid: "PERINEURIUM = thin, distinct RIM around each fascicle. EPINEURIUM = thick, loose tissue BETWEEN fascicles with adipocytes. Perineurium is organized and regular; epineurium is bulky and irregular."
        },
        {
          mistake: "Missing the blood-nerve barrier function",
          why: "It looks like simple connective tissue",
          avoid: "Remember: perineurium has TIGHT JUNCTIONS between specialized epithelioid cells - it's a functional BARRIER, not just structural support! This is high-yield for exams."
        }
      ]
    },
    {
      structure: "Epineurium",
      identificationTips: [
        "Thick pink connective tissue filling spaces between fascicles and surrounding the entire nerve",
        "Contains large white adipocytes (much larger than myelin spaces)",
        "Contains visible blood vessels (vasa nervorum) with red blood cells",
        "Loose, irregular arrangement compared to the organized perineurium",
        "Forms the outermost coat of the nerve visible at low magnification"
      ],
      commonMistakes: [
        {
          mistake: "Thinking adipocytes in epineurium are enlarged myelin sheaths",
          why: "Both appear as white spaces",
          avoid: "LOCATION: adipocytes are OUTSIDE fascicles (in epineurium), myelin is INSIDE fascicles. SIZE: adipocytes are 3× larger (50-150 μm) vs myelin (5-15 μm). PATTERN: adipocytes are scattered irregularly, myelin forms honeycomb."
        },
        {
          mistake: "Confusing blood vessels in epineurium with nerve structures",
          why: "Both contain circular profiles",
          avoid: "Blood vessels have red blood cells inside and an endothelial lining. Nerve fascicles have honeycomb pattern inside and perineurial rim."
        }
      ]
    },
    {
      structure: "Adipocytes (fat cells)",
      identificationTips: [
        "Large white circular spaces located in EPINEURIUM (between fascicles)",
        "Much larger than myelin spaces (50-150 μm vs 5-15 μm = 3× or more difference)",
        "Variable sizes (unlike uniform myelin)",
        "May have flattened nucleus pushed to periphery (signet-ring appearance)",
        "Located OUTSIDE the perineurial boundary, never inside fascicles"
      ],
      commonMistakes: [
        {
          mistake: "Confusing large adipocytes with myelin sheaths",
          why: "Both appear as white spaces in HE",
          avoid: "SIZE: Adipocytes much larger. LOCATION: Adipocytes OUTSIDE fascicles (epineurium), myelin INSIDE fascicles. PATTERN: Adipocytes scattered, myelin organized in honeycomb. Ask: 'Is it inside or outside the pink rim?' If outside = adipocyte."
        },
        {
          mistake: "Thinking adipocytes are pathological",
          why: "They're conspicuous and may seem like artifacts",
          avoid: "Adipocytes are NORMAL components of epineurium! They provide cushioning and energy storage for the nerve."
        }
      ]
    },
    {
      structure: "Blood vessels (vasa nervorum)",
      identificationTips: [
        "Small arterioles, capillaries, and venules visible in epineurium",
        "May show red blood cells (pink/orange circular profiles) in lumen",
        "Endothelial cell nuclei visible as flattened blue nuclei lining vessel wall",
        "Usually accompanied by small amounts of connective tissue",
        "Found in epineurium, not inside fascicles (which have only capillaries in endoneurium)"
      ],
      commonMistakes: [
        {
          mistake: "Confusing blood vessels with nerve fascicles",
          why: "Both are circular structures",
          avoid: "Blood vessels have RED BLOOD CELLS and endothelial lining. Fascicles have HONEYCOMB PATTERN and perineurial rim. Blood vessels are smaller and lack the internal honeycomb structure."
        }
      ]
    }
  ],

  criticalRelationships: [
    {
      title: "CNS-PNS Transition Zone (HIGH-YIELD EXAM TOPIC!)",
      content: "At the nerve roots where peripheral nerves enter or exit the CNS, the three connective tissue layers transition directly to the three meningeal layers. This transition zone is clinically significant and frequently tested.",
      details: [
        "Endoneurium → Pia mater (innermost, delicate vascular layer adhering to neural tissue)",
        "Perineurium → Arachnoid mater (middle, avascular barrier layer with tight junctions)",
        "Epineurium → Dura mater (outermost, tough fibrous protective layer)",
        "Transition occurs at CNS-PNS junction at nerve root entry/exit zones",
        "Blood-nerve barrier (perineurium with tight junctions) is continuous with blood-brain barrier at this transition",
        "Schwann cells in PNS are replaced by oligodendrocytes in CNS at this junction",
        "This anatomical continuity explains why infections can spread from peripheral nerves to CNS",
        "Understanding this transition is essential for comprehending pathologies like Guillain-Barré syndrome which affects nerve roots at this junction"
      ],
      emphasis: "This parallel 3-layer protective system is ESSENTIAL to understand for medical exams. The continuity ensures protected nerve roots and explains bidirectional pathology spread. Exams love testing the CNS equivalents and barrier continuity!"
    },
    {
      title: "Blood-Nerve Barrier: Perineurium's Critical Role (EXAM FAVORITE!)",
      content: "The perineurium forms the blood-nerve barrier through its specialized epithelioid cells connected by tight junctions. This selective permeability barrier is analogous to the blood-brain barrier and is clinically significant.",
      details: [
        "Formed by 2-6 concentric layers of epithelioid perineural cells (modified fibroblasts with epithelial characteristics)",
        "Tight junctions (zonulae occludentes) between perineural cells create impermeable seal controlling molecular diffusion",
        "Each cellular layer surrounded by basement membrane providing additional filtration",
        "Regulates ionic composition (Na⁺, K⁺, Ca²⁺) essential for action potential propagation",
        "Protects nerve fibers from toxins, pathogens, and large molecules in bloodstream",
        "Maintains stable osmotic environment within fascicles for optimal nerve conduction",
        "Analogous to blood-brain barrier (BBB) in CNS - both use tight junctions for selective permeability",
        "Clinical importance: disruption causes neuropathies; some drugs can't penetrate it (therapeutic challenge); inflammation can compromise barrier leading to nerve edema"
      ],
      emphasis: "The blood-nerve barrier is HIGH-YIELD for exams! Know its structure (tight junctions in perineurium), function (selective barrier), and clinical relevance (diabetic neuropathy, drug delivery challenges, Guillain-Barré pathophysiology)."
    },
    {
      title: "Size Comparison: Myelin vs Adipocytes (CRITICAL DISTINCTION - MOST COMMON CONFUSION!)",
      content: "Both myelin sheaths and adipocytes appear as white spaces in HE sections because lipids are dissolved during tissue processing. However, they are easily distinguished by three key features: SIZE, LOCATION, and ASSOCIATED STRUCTURES.",
      details: [
        "SIZE: Myelin small (5-15 μm diameter), uniform; Adipocytes large (50-150 μm, 3-10× bigger), variable",
        "LOCATION: Myelin INSIDE fascicles (within perineurial boundary); Adipocytes OUTSIDE fascicles in EPINEURIUM",
        "PATTERN: Myelin creates uniform honeycomb pattern; Adipocytes scattered irregularly with variable spacing",
        "MYELIN has: central pink axon dot + peripheral Schwann nucleus (dark crescent at edge)",
        "ADIPOCYTES have: flattened nucleus at periphery (signet-ring), NO central structure, larger empty space",
        "MYELIN surrounded by thin endoneurium; ADIPOCYTES surrounded by thick irregular collagen in epineurium",
        "If confused, ask two questions: (1) Is it inside or outside the pink perineurial rim? (2) What's the relative size?",
        "Remember: Myelin = honeycomb INSIDE, Adipocytes = scattered OUTSIDE"
      ],
      emphasis: "This is THE MOST COMMON MISTAKE on exams! SIZE and LOCATION are the two critical discriminating features. If you can't tell, ask yourself: 'Is it inside or outside the fascicle?' This simple question solves 90% of confusion. Memorize: Small + Inside = Myelin, Large + Outside = Adipocyte."
    },
    {
      title: "Hierarchical Organization: Three-Level Wrapping Pattern (HIGH-YIELD!)",
      content: "Understanding the hierarchical wrapping pattern is essential for nerve identification and injury classification. Each level provides progressively stronger protection and has distinct CNS equivalents.",
      details: [
        "Level 1 (Innermost): Single axon + myelin + Schwann cell wrapped by ENDONEURIUM (delicate loose CT) = Pia mater equivalent",
        "Level 2 (Middle): Bundle of nerve fibers (fascicle) wrapped by PERINEURIUM (epithelioid cells with tight junctions) = Arachnoid mater equivalent",
        "Level 3 (Outermost): Bundle of fascicles (whole nerve) wrapped by EPINEURIUM (dense irregular CT with adipose) = Dura mater equivalent",
        "Each successively outer layer provides stronger mechanical protection",
        "Analogy: Wire (axon) → insulated wire (fiber with endoneurium) → cable (fascicle with perineurium) → bundled cables with protective jacket (nerve with epineurium)",
        "Nerve injury classification based on this hierarchy: Neuropraxia (myelin only), Axonotmesis (axon + endoneurium), Neurotmesis (all layers)",
        "The hierarchical pattern allows nerves to stretch and bend without damage - layers slide over each other",
        "Blood supply also follows hierarchy: Vasa nervorum in epineurium → branches to perineurium → capillaries in endoneurium"
      ],
      emphasis: "This hierarchical wrapping pattern is your complete roadmap for nerve identification and injury classification! Understanding the 3-level organization is ESSENTIAL for both identifying peripheral nerves on slides and understanding clinical nerve injury patterns. Exams love asking about CNS equivalents and injury classifications based on this hierarchy."
    }
  ],

  relationshipsSummary: [
    {
      title: "CNS-PNS Continuity (HIGH-YIELD!)",
      summary: "At nerve roots, the 3 nerve layers directly transition to meninges: Endo→Pia, Peri→Arachnoid, Epi→Dura, maintaining protective barrier continuity.",
      keyPoints: [
        "Direct 1:1 layer transition at CNS-PNS junction",
        "Blood-nerve barrier continuous with blood-brain barrier",
        "Explains infection spread between PNS and CNS",
        "Key for Guillain-Barré pathophysiology"
      ]
    },
    {
      title: "Blood-Nerve Barrier Function (HIGH-YIELD!)",
      summary: "Perineurium forms selective barrier via tight junctions between epithelioid cells, protecting fascicles like BBB protects brain.",
      keyPoints: [
        "Tight junctions in perineurium control molecular passage",
        "Maintains ionic environment for action potentials",
        "Disruption causes neuropathies and nerve edema",
        "Analogous to blood-brain barrier"
      ]
    },
    {
      title: "Myelin vs Adipocyte Distinction (EXAM FAVORITE!)",
      summary: "Both white in HE (lipids removed), but differ critically: Myelin small/inside fascicles/honeycomb; Adipocytes large/outside/scattered.",
      keyPoints: [
        "SIZE: Myelin 5-15μm vs Adipocytes 50-150μm (3× larger)",
        "LOCATION: Myelin inside fascicles, Adipocytes in epineurium",
        "PATTERN: Myelin uniform honeycomb, Adipocytes irregular",
        "Ask: Inside or outside pink rim? Solves confusion!"
      ]
    },
    {
      title: "Three-Level Hierarchy (HIGH-YIELD!)",
      summary: "Wrapping pattern: Endo wraps axon (Level 1) → Peri wraps fascicle (Level 2) → Epi wraps nerve (Level 3). Basis for injury classification.",
      keyPoints: [
        "Each level = progressively stronger protection",
        "Analogy: Wire → Cable → Bundled cables",
        "Nerve injury severity based on which layers damaged",
        "CNS equivalents: Pia → Arachnoid → Dura"
      ]
    }
  ],

  keyIdentifyingFeatures: [
    "**Honeycomb pattern** - The pathognomonic feature! White circular spaces (myelin sheaths) with pink centers (axons) arranged in uniform honeycomb pattern INSIDE fascicles bounded by pink perineurial rims",
    "**Three distinct connective tissue layers** - From inside out: (1) Endoneurium (barely visible thin pink between fibers), (2) Perineurium (distinct pink rim around each fascicle), (3) Epineurium (thick pink tissue with adipocytes between fascicles)",
    "**Pink perineurial rims** - Smooth, continuous pink boundaries clearly demarcating each fascicle. This is your anchor structure - once you find these rims, everything else falls into place",
    "**White spaces in TWO locations** - Small uniform white circles (myelin) INSIDE fascicles creating honeycomb + large variable white spaces (adipocytes) OUTSIDE fascicles in epineurium",
    "**Schwann cell nuclei** - Dark blue elongated nuclei at the periphery of some myelin rings, appearing as crescents pressed against the inner edge",
    "**Cross-sectional circular profiles** - Everything appears round: axons (tiny pink dots), myelin rings (white circles), fascicles (large circular bundles), adipocytes (large white circles)",
    "**Size hierarchy visible** - Tiny axon dots (few μm) inside small myelin rings (5-15 μm) inside larger fascicles (hundreds of μm) inside entire nerve (mm scale), with large adipocytes (50-150 μm) in between"
  ],

  comparisonWithOtherStains: [
    {
      stain: "OsO₄ (Osmium tetroxide)",
      differences: [
        "In OsO₄, myelin appears BLACK (stains lipids) vs WHITE in HE (lipids dissolved)",
        "In OsO₄, axon appears as white/pale space (unstained) vs tiny pink dot in HE",
        "OsO₄ creates 'negative' of HE image: dark rings with white centers (OsO₄) vs white rings with pink centers (HE)",
        "Both show honeycomb pattern, but colors reversed",
        "OsO₄ better for visualizing myelin integrity; HE better for overall nerve architecture and nuclei",
        "In longitudinal OsO₄ sections, Nodes of Ranvier visible as gaps in black myelin (not visible in HE longitudinal)"
      ],
      when: "Slides 72-73 use OsO₄ - compare to see the reversal of myelin appearance"
    },
    {
      stain: "Silver stain (Ag)",
      differences: [
        "Silver stain shows nerve fibers/neurofibrils as BLACK structures",
        "Used for demonstrating nerve endings and fine axonal processes",
        "Better for showing nerve fiber distribution in tissues (e.g., Meissner's corpuscle in Slide 75)",
        "HE better for showing connective tissue organization and general architecture"
      ],
      when: "Slide 75 (Meissner's corpuscle) uses silver stain to show nerve endings"
    }
  ],

  commonMistakes: [
    {
      mistake: "Confusing myelin spaces with adipocytes (THE MOST COMMON ERROR!)",
      why: "Both appear as white spaces in HE sections due to lipid dissolution during tissue processing. Students often identify all white spaces as one type of structure without considering size, location, and context.",
      avoid: "Use the 'SIZE + LOCATION' rule: (1) SIZE: Myelin small (5-15 μm), uniform; Adipocytes large (50-150 μm), variable (3-10× bigger). (2) LOCATION: Myelin INSIDE fascicles (within pink perineurial rim); Adipocytes OUTSIDE fascicles in epineurium. (3) PATTERN: Myelin organized honeycomb; Adipocytes scattered. Simple test: Ask 'Is it inside or outside the pink rim?' Inside = myelin, Outside = adipocyte. This solves 90% of confusion!"
    },
    {
      mistake: "Identifying the white space as the axon instead of myelin",
      why: "Students expect axons to be the most prominent structures since they carry nerve impulses. The white spaces are eye-catching, leading to misidentification.",
      avoid: "The white space is the MYELIN SHEATH (negative image from lipid removal), NOT the axon! The axon is the tiny PINK DOT in the CENTER of the white ring. Remember: HE dissolves lipids → myelin appears as white space. The axon cytoplasm (pale pink) is preserved and visible as a small central dot."
    },
    {
      mistake: "Confusing Schwann cell nuclei with axons",
      why: "Both appear as dark structures within or near the myelin ring. Students see a dark structure and assume it's the nerve fiber.",
      avoid: "AXON = tiny PINK dot in CENTER of white ring. SCHWANN NUCLEUS = larger BLUE crescent at PERIPHERY of white ring. Key differences: (1) Location: center vs periphery, (2) Color: pink vs blue/purple, (3) Size: very small vs larger, (4) Shape: round dot vs elongated crescent."
    },
    {
      mistake: "Confusing perineurium with epineurium (mixing up the layers)",
      why: "Both are pink connective tissue, and students don't carefully observe the structural differences and locations.",
      avoid: "PERINEURIUM = thin, DISTINCT RIM that ENCIRCLES each fascicle (looks like a pink border or frame). EPINEURIUM = thick, LOOSE tissue that FILLS SPACES BETWEEN fascicles and contains adipocytes + blood vessels. Mnemonic: 'Peri' = 'perimeter' = rim around fascicle. 'Epi' = 'epidural' = loose filling tissue. The perineurium is organized and precise; epineurium is bulky and irregular."
    },
    {
      mistake: "Expecting to see pink or black myelin in HE stain",
      why: "Students confuse different staining protocols or expect myelin to take up standard stains like other structures.",
      avoid: "In HE, myelin ALWAYS appears WHITE (negative image) because LIPIDS ARE DISSOLVED during processing. Myelin only appears black in OsO₄ (osmium tetroxide) stain (Slides 72-73). Never expect pink myelin - it doesn't happen in any stain! Remember: HE = white myelin, OsO₄ = black myelin."
    },
    {
      mistake: "Missing the honeycomb pattern entirely",
      why: "Students scan at low power or focus on the outer layers without examining fascicle interiors closely.",
      avoid: "The honeycomb pattern is THE DIAGNOSTIC FEATURE of peripheral nerve! You MUST look INSIDE the fascicles (areas bounded by pink perineurial rims) at higher magnification. Don't just identify pink layers - look for the characteristic white circles with pink centers arranged in honeycomb pattern. No honeycomb = might not be peripheral nerve or wrong region of slide!"
    },
    {
      mistake: "Thinking the entire nerve is one fascicle",
      why: "Students see one prominent bundle and call it 'the nerve' without recognizing the individual fascicles within.",
      avoid: "Look for MULTIPLE pink rims (perineurium) dividing the nerve into SEPARATE FASCICLES. Each pink rim = one fascicle boundary. The WHOLE NERVE = epineurium + ALL fascicles together. Most peripheral nerves contain multiple fascicles of varying sizes. Scan at low power first to appreciate the multi-fascicular architecture."
    },
    {
      mistake: "Confusing blood vessels in epineurium with nerve fascicles",
      why: "Both are circular structures when cut in cross-section.",
      avoid: "BLOOD VESSELS have: (1) RED BLOOD CELLS inside (pink/orange circular profiles), (2) endothelial cell nuclei lining the wall, (3) NO honeycomb pattern. FASCICLES have: (1) honeycomb pattern of myelin inside, (2) pink perineurial rim around border, (3) NO red blood cells. Blood vessels are also much smaller than typical fascicles."
    },
    {
      mistake: "Forgetting the CNS equivalents (Pia-Arachnoid-Dura)",
      why: "Students memorize the three layers but don't connect them to CNS meninges.",
      avoid: "ALWAYS remember: Endoneurium ↔ Pia mater, Perineurium ↔ Arachnoid mater, Epineurium ↔ Dura mater. This parallel is HIGH-YIELD for exams! The layers transition directly at nerve roots. Mnemonic: 'EPA connects to PAD' (Endo-Peri-Epi = Pia-Arachnoid-Dura, inner to outer)."
    },
    {
      mistake: "Not recognizing that perineurium forms the blood-nerve barrier",
      why: "It looks like simple connective tissue, and students miss the functional significance.",
      avoid: "The perineurium is NOT just structural support - it's a FUNCTIONAL BARRIER! It contains specialized epithelioid cells with TIGHT JUNCTIONS that create the blood-nerve barrier (analogous to blood-brain barrier). This is clinically important and HIGH-YIELD for exams. Always mention barrier function when discussing perineurium!"
    }
  ],

  clinicalCorrelations: [
    {
      condition: "Diabetic Neuropathy",
      relevance: "Chronic hyperglycemia damages the blood-nerve barrier (perineurium) and endoneurial capillaries, leading to disrupted ionic balance, oxidative stress, and nerve fiber degeneration. Advanced glycation end-products (AGEs) accumulate in nerve tissue. Results in peripheral sensory loss (glove-and-stocking distribution), pain, and motor weakness. The endoneurium is particularly vulnerable due to its rich capillary network."
    },
    {
      condition: "Guillain-Barré Syndrome (GBS)",
      relevance: "Autoimmune demyelination targeting peripheral nerves, often triggered by infection. Immune cells cross the compromised blood-nerve barrier (perineurium) and attack myelin sheaths produced by Schwann cells. The damage occurs particularly at nerve roots where PNS layers transition to CNS meninges. Results in ascending paralysis, areflexia, and potential respiratory failure. Understanding the three-layer structure and CNS transition zone is essential for comprehending GBS pathophysiology."
    },
    {
      condition: "Nerve Injury Classification (Seddon & Sunderland)",
      relevance: "Based on the hierarchical three-layer structure: (1) **Neuropraxia**: Myelin damage only, Schwann cells intact, endoneurium preserved → excellent recovery. (2) **Axonotmesis**: Axon disrupted, endoneurium may be damaged, but perineurium and epineurium intact → good recovery with Wallerian degeneration. (3) **Neurotmesis**: Complete nerve transection, all three layers disrupted → poor recovery, requires surgical intervention. Understanding the anatomical hierarchy is essential for predicting outcomes."
    },
    {
      condition: "Carpal Tunnel Syndrome",
      relevance: "Chronic compression of median nerve at wrist causes venous congestion in vasa nervorum (blood vessels in epineurium), leading to endoneurial edema. The blood-nerve barrier (perineurium) may become compromised. Over time, myelin sheaths degenerate and axons become damaged. Results in sensory deficits and weakness in median nerve distribution. The three-layer structure normally provides protection, but chronic compression overwhelms these defenses."
    },
    {
      condition: "Leprosy (Hansen's Disease)",
      relevance: "*Mycobacterium leprae* specifically infects Schwann cells in peripheral nerves, causing progressive demyelination and nerve fiber loss. The bacteria preferentially invade Schwann cells in cooler body regions (extremities, ears, nose). Destruction of Schwann cells leads to loss of myelin sheaths and sensory nerve damage. Results in anesthetic skin patches, nerve thickening, and deformities. Understanding Schwann cell structure and location is key to understanding leprosy pathogenesis."
    },
    {
      condition: "Charcot-Marie-Tooth Disease (CMT)",
      relevance: "Hereditary peripheral neuropathy affecting myelin (CMT1) or axons (CMT2). In demyelinating forms (CMT1), mutations in myelin genes (PMP22, MPZ) cause abnormal Schwann cell function and myelin production. Results in progressive muscle weakness, sensory loss, and foot deformities. Nerve biopsies show 'onion bulb' formations (concentric Schwann cell proliferation). Understanding normal Schwann cell-myelin-axon relationships is essential for comprehending CMT pathology."
    },
    {
      condition: "Nerve Blocks and Local Anesthesia",
      relevance: "Local anesthetics must penetrate through the three connective tissue layers (especially epineurium and perineurium) to reach nerve fibers within fascicles. The blood-nerve barrier (perineurium with tight junctions) restricts drug penetration. Larger nerves with thick epineurium require more anesthetic or longer onset time. Understanding the barrier properties of perineurium explains why some nerve blocks require higher concentrations or specific injection techniques."
    }
  ],

  functionalContext: "Peripheral nerves serve as the communication highways between the central nervous system and all body tissues. The three-layer connective tissue organization provides mechanical protection during movement and stretching, vascular supply through the vasa nervorum network, and selective barrier function to maintain optimal ionic environment for action potential propagation. The hierarchical structure allows flexibility while protecting delicate axons - layers slide over each other during limb movement. Myelination by Schwann cells enables saltatory conduction, dramatically increasing conduction velocity (up to 120 m/s in large myelinated fibers vs. 0.5-2 m/s in unmyelinated fibers). Mixed peripheral nerves contain motor fibers (from anterior horn cells), sensory fibers (from dorsal root ganglia), and autonomic fibers (from autonomic ganglia), all organized within the same three-layer protective framework.",

  identificationTips: [
    "**START with fascicles**: At low power, identify the pink perineurial rims that clearly demarcate individual fascicles. These distinct pink boundaries are your anchor structures.",
    "**LOOK for honeycomb**: Within each fascicle, look for the diagnostic honeycomb pattern of white circular spaces (myelin) with tiny pink dots (axons) at higher magnification. No honeycomb = not nerve!",
    "**Identify the THREE layers** systematically from inside out: (1) Endoneurium (barely visible thin pink between fibers inside fascicles), (2) Perineurium (distinct pink rim around each fascicle), (3) Epineurium (thick pink tissue with adipocytes between fascicles and surrounding entire nerve).",
    "**Distinguish white spaces** by location and size: White circles INSIDE fascicles = myelin (small, 5-15 μm, uniform, honeycomb pattern). White spaces OUTSIDE fascicles = adipocytes (large, 50-150 μm, variable, scattered in epineurium).",
    "**Use the 'inside or outside' rule**: If confused about a white space, ask: 'Is it inside or outside the pink perineurial rim?' Inside = myelin, Outside = adipocyte. This simple question solves most confusion!",
    "**Remember the EPA mnemonic** for outer to inner layers: **E**pineurium (thickest, adipocytes, surrounds everything) → **P**erineurium (pink rim, blood-nerve barrier) → **A**xons with endoneurium (inside bundles). Or remember 'PAD' for CNS: **P**ia → **A**rachnoid → **D**ura corresponds to Endo → Peri → Epi.",
    "**Cross section vs longitudinal**: This is CROSS section - everything appears circular/round (axons, myelin rings, fascicles). In longitudinal sections (Slide 71), structures appear elongated and wavy, and Nodes of Ranvier may be visible.",
    "**Compare with OsO₄ stain**: If you see BLACK circular structures instead of white spaces inside fascicles, you're looking at OsO₄ stain (Slide 72), not HE! HE = white myelin, OsO₄ = black myelin.",
    "**The honeycomb + pink rim combination is pathognomonic**: Honeycomb pattern (white circles with pink centers) inside bundles + distinct pink rims around bundles + thick outer coat with adipocytes = peripheral nerve in cross section with HE stain. This combination is diagnostic!",
    "**Don't forget functional correlations**: The perineurium (pink rim) is the blood-nerve barrier. The three layers correspond to CNS meninges (Pia-Arachnoid-Dura). Mentioning these relationships demonstrates complete understanding!"
  ],

  examTips: [
    "**Most commonly tested**: (1) CNS equivalents (Endo=Pia, Peri=Arachnoid, Epi=Dura), (2) Blood-nerve barrier location (perineurium with tight junctions), (3) Distinguishing myelin from adipocytes (size + location rule), (4) What appears WHITE in HE (myelin + adipocytes, lipids dissolved).",
    "**High-yield relationships**: Always connect peripheral nerve layers to CNS meninges - exams love this parallel! The transition occurs at nerve roots. Blood-nerve barrier (perineurium) is continuous with blood-brain barrier.",
    "**Common exam questions**: 'Why does myelin appear white in HE?' (lipids dissolved during processing). 'What forms the blood-nerve barrier?' (perineurium with tight junctions). 'What's the difference between myelin and adipocytes?' (size, location, pattern). Be ready for these!",
    "**Know the hierarchical organization**: Level 1: Endoneurium wraps axon. Level 2: Perineurium wraps fascicle. Level 3: Epineurium wraps nerve. This hierarchy forms the basis for nerve injury classification (neuropraxia, axonotmesis, neurotmesis).",
    "**Stain comparison is tested**: Know how myelin appears in different stains: HE = WHITE (lipids dissolved), OsO₄ = BLACK (lipids stained). This creates 'negative images' of each other.",
    "**Clinical correlations are high-yield**: Diabetic neuropathy (blood-nerve barrier damage), Guillain-Barré (demyelination), nerve injury classification (based on layer damage), carpal tunnel (compression). Connecting histology to pathology shows deep understanding.",
    "**Schwann cells vs Schwann nuclei vs axons**: Exams test this! Schwann CELL = entire cell that wraps axon. Schwann NUCLEUS = blue crescent at periphery of myelin ring. AXON = tiny pink dot in center of myelin ring. Don't confuse these!",
    "**Blood supply pattern**: Vasa nervorum in epineurium → branches through perineurium → capillaries in endoneurium. Understanding this explains why nerve compression causes ischemia.",
    "**Honeycomb is THE diagnostic feature**: If asked to identify peripheral nerve, always mention the honeycomb pattern! It's the single most important identifying feature. White circles with pink centers in uniform arrangement inside fascicles = peripheral nerve.",
    "**Function follows form**: Endoneurium provides microenvironment (function: metabolic support). Perineurium has tight junctions (function: blood-nerve barrier). Epineurium has adipose (function: cushioning, vascular supply). Connecting structure to function earns extra points!",
    "**Cross-sectional view specifics**: Everything appears round/circular (axons, myelin, fascicles). In longitudinal view, structures are elongated and wavy. Nodes of Ranvier only visible in longitudinal sections.",
    "**Size matters**: Know approximate sizes - Axon: few μm, Myelin: 5-15 μm, Adipocyte: 50-150 μm (3-10× larger than myelin). Fascicle: hundreds of μm to mm. Being able to estimate sizes helps distinguish structures."
  ],

  ultraMinimalFacts: {
    staining: "HE: Myelin = WHITE (lipids dissolved), not pink. Honeycomb = key!",
    layers: [
      "• ENDO = wraps 1 fiber (Pia)",
      "• PERI = wraps bundle (Arachnoid) - barrier!",
      "• EPI = wraps nerve (Dura)"
    ],
    visualID: [
      "• Honeycomb inside fascicles = myelin (white circles)",
      "• Dark nuclei at edge of rings = Schwann cells",
      "• Pink rim around bundles = perineurium",
      "• Large white outside fascicles = adipocytes"
    ],
    cnsConnection: "Endo → Peri → Epi = Pia → Arachnoid → Dura (at nerve roots)",
    dontConfuse: [
      "• Myelin (small, inside) ≠ Adipocyte (large, outside)",
      "• Schwann nucleus (edge) ≠ Axon (center dot)",
      "• HE myelin (white) ≠ OsO₄ myelin (black)"
    ]
  }
};

const SLIDE_DATA_71 = {
  slideNumber: "71",
  name: "Peripheral Nerve - Longitudinal Section (HE)",
  section: "longitudinal section",
  stain: "HE",
  
  bigPicture: "Peripheral nerve = axons wrapped in 3 protective CT layers (like CNS meninges!)",
  
  hierarchy: [
    "Axon -> Fascicle -> Whole Nerve",
    "v ENDO -> PERI -> EPI",
    "v (Pia) -> (Arachnoid) -> (Dura)"
  ],
  
  insideTheFascicles: [
    {
      structure: "Axon",
      description: "Long continuous pink strand running parallel; carries electrical impulses along nerve length"
    },
    {
      structure: "Myelin sheath (negative image)",
      description: "White longitudinal spaces flanking axons; lipid dissolved during processing creating linear pattern"
    },
    {
      structure: "Schwann cell nucleus",
      description: "Elongated dark blue/purple nuclei aligned along myelin; each Schwann cell myelinates one internode"
    },
    {
      structure: "Wavy fiber pattern",
      description: "Characteristic undulating appearance of relaxed nerve fibers; allows stretching without damage"
    },
    {
      structure: "Endoneurium",
      description: "Delicate pink CT between fibers running longitudinally; supports individual axons"
    }
  ],
  
  stainingInfo: {
    technique: "HE (Hematoxylin and Eosin)",
    description: "Hematoxylin stains nuclei blue/purple (basophilic structures like chromatin, rough ER). Eosin stains cytoplasm and collagen pink/red (acidophilic structures like proteins).",
    whatItStainsInThisSlide: [
      "Axon cytoplasm â†' Pink (acidophilic proteins)",
      "Schwann cell nuclei â†' Dark blue/purple (basophilic chromatin)",
      "Fibrocyte nuclei â†' Dark blue/purple (in connective tissue layers)",
      "Endoneurium, perineurium, epineurium â†' Pink (collagen-rich CT)",
      "Myelin sheath â†' WHITE SPACE (negative image - lipids dissolved during processing)",
      "Blood vessel walls â†' Pink (in epineurium)",
      "Adipocyte cytoplasm â†' WHITE SPACE (lipids dissolved)"
    ],
    keyEmphasis: "In this longitudinal section, HE staining creates a distinctive wavy pattern of pink axons flanked by white linear myelin spaces. The key diagnostic feature is that myelin appears as NEGATIVE IMAGES (white spaces) because lipids are extracted during tissue processing, unlike osmium tetroxide staining where myelin appears black. The wavy appearance of nerve fibers is characteristic of longitudinal sections and represents the relaxed, unstressed state of nerves."
  },

  layers: [
    {
      name: "Endoneurium",
      level: "Innermost layer (Level 1)",
      wraps: "Individual nerve fiber (single axon + myelin sheath + Schwann cell)",
      composition: "Delicate loose connective tissue with reticular fibers (Type III collagen), scattered fibroblasts, and longitudinally oriented capillaries",
      appearance: "Very thin pink tissue running longitudinally between individual nerve fibers. Appears as delicate pink strands separating the white myelin spaces along fiber length.",
      contains: "Endoneurial capillaries (part of blood-nerve barrier), fibroblasts, reticular fibers, tissue fluid that bathes each nerve fiber",
      cnsEquivalent: "Pia mater (direct continuous transition at CNS-PNS junction at nerve roots)",
      function: "Provides microenvironment for individual nerve fibers, supports axon nutrition through capillaries, maintains ionic balance necessary for nerve conduction, allows metabolic exchange",
      quickID: "Thinnest pink layer running along length of fibers, barely visible between individual axons"
    },
    {
      name: "Perineurium",
      level: "Middle layer (Level 2)",
      wraps: "Fascicle (bundle of multiple nerve fibers)",
      composition: "2-6 concentric layers of specialized epithelioid perineural cells (modified fibroblasts) connected by tight junctions, each layer surrounded by basement membrane",
      appearance: "Distinct pink boundary running along entire fascicle length, appearing as continuous longitudinal borders on both sides of each bundle. More prominent than endoneurium.",
      contains: "Perineural cells with tight junctions forming blood-nerve barrier, basement membrane, occasional fibroblasts, perineurial space",
      cnsEquivalent: "Arachnoid mater (continuous transition at nerve roots)",
      function: "Forms blood-nerve barrier by controlling diffusion of substances into and out of fascicle through tight junctions, maintains stable microenvironment for saltatory conduction, protects against mechanical stress and toxic substances",
      quickID: "Pink longitudinal border running along each fascicle edge - the fascicle boundary"
    },
    {
      name: "Epineurium",
      level: "Outermost layer (Level 3)",
      wraps: "Entire nerve (multiple fascicles together)",
      composition: "Dense irregular connective tissue with thick collagen bundles oriented in multiple directions, adipose tissue, fibroblasts, blood vessels (vasa nervorum), and lymphatics",
      appearance: "Thick pink connective tissue surrounding fascicles and filling spaces between them. Contains large white adipocytes (also negative images) and blood vessels. Provides substantial padding.",
      contains: "Vasa nervorum (blood vessels supplying the nerve), lymphatics, adipose tissue, fibroblasts producing collagen, nervi nervorum (small nerves innervating nerve sheaths)",
      cnsEquivalent: "Dura mater (continuous with dura at nerve roots)",
      function: "Provides mechanical protection and cushioning, supplies vascular network (vasa nervorum) for nerve nutrition, allows nerve mobility during limb movement, protects from compression",
      quickID: "Thickest layer with adipocytes, surrounds entire nerve and fills spaces between fascicles"
    }
  ],

  essentialStructures: [
    {
      name: "Axon (continuous strand)",
      identificationTips: [
        "Appears as long, continuous pink strand running parallel to nerve length",
        "Much thinner than the surrounding myelin white space in longitudinal view",
        "Shows slight waviness characteristic of relaxed nerve fibers",
        "Central position within each myelin negative image"
      ],
      commonMistakes: [
        {
          mistake: "Confusing the axon with the entire nerve fiber",
          why: "The nerve fiber includes axon + myelin + Schwann cell, not just the axon",
          avoid: "Remember: axon is only the pink center strand, the whole fiber includes all components"
        },
        {
          mistake: "Expecting axons to be straight lines",
          why: "Relaxed nerves naturally have a wavy pattern for flexibility",
          avoid: "The waviness is normal and protective - it allows stretching during movement"
        }
      ]
    },
    {
      name: "Myelin sheath (negative image - longitudinal)",
      identificationTips: [
        "White longitudinal spaces running parallel to axons on both sides",
        "Create a linear, parallel pattern along nerve fiber length (not circular like in cross section)",
        "Flanks the central pink axon strand creating a 'track' appearance",
        "Interrupted at regular intervals by Nodes of Ranvier (gaps in myelin)"
      ],
      commonMistakes: [
        {
          mistake: "Looking for circular myelin patterns like in cross sections",
          why: "Longitudinal sections show linear myelin, not circles",
          avoid: "Adjust mental image: cross section = honeycomb circles, longitudinal = parallel tracks"
        },
        {
          mistake: "Thinking myelin stains white in HE",
          why: "Myelin is NOT stained - it's a negative image from lipid extraction",
          avoid: "Remember: WHITE = ABSENCE of myelin lipids, not white staining"
        },
        {
          mistake: "Confusing longitudinal myelin spaces with adipocytes",
          why: "Both appear white, but very different locations and patterns",
          avoid: "Myelin = linear tracks inside fascicles along fibers; Adipocytes = large irregular spaces in epineurium"
        }
      ]
    },
    {
      name: "Schwann cell nuclei",
      identificationTips: [
        "Elongated dark blue/purple nuclei aligned along myelin sheaths",
        "Located at periphery of myelin, adjacent to the white myelin space",
        "Multiple nuclei visible along each nerve fiber length",
        "Distinguished from fibrocyte nuclei by their association with myelin and regular spacing"
      ],
      commonMistakes: [
        {
          mistake: "Confusing Schwann nuclei with fibrocyte nuclei",
          why: "Both stain dark blue, but have different locations and functions",
          avoid: "Schwann nuclei = aligned with myelin sheaths; Fibrocyte nuclei = scattered in CT layers"
        },
        {
          mistake: "Expecting one Schwann nucleus per fiber",
          why: "Each internode (segment between Nodes of Ranvier) has its own Schwann cell",
          avoid: "Look for multiple Schwann nuclei along each fiber's length"
        }
      ]
    },
    {
      name: "Wavy fiber pattern",
      identificationTips: [
        "Distinctive undulating, serpentine appearance of nerve fibers",
        "Most obvious diagnostic feature distinguishing longitudinal from cross sections",
        "Wave pattern is gentle and regular, not chaotic",
        "Present in all fibers within fascicles, creating synchronized wavy bundles"
      ],
      commonMistakes: [
        {
          mistake: "Thinking waviness indicates damaged or pathological nerves",
          why: "Waviness is NORMAL in relaxed, unstretched nerves",
          avoid: "Understand that waviness is protective - it provides reserve length for stretching during movement"
        },
        {
          mistake: "Not recognizing waviness as diagnostic for longitudinal sections",
          why: "This is THE key feature that immediately identifies longitudinal orientation",
          avoid: "Use waviness as your first clue: wavy = longitudinal section"
        }
      ]
    },
    {
      name: "Bundle of nerve fibers (fascicle)",
      identificationTips: [
        "Collection of parallel wavy fibers bounded by pink perineurium",
        "Appears as elongated bundle with distinct longitudinal borders",
        "Multiple fascicles may be visible, each wrapped separately",
        "Interior shows repeating pattern of pink axons with white myelin spaces"
      ],
      commonMistakes: [
        {
          mistake: "Not recognizing fascicle boundaries",
          why: "Perineurium borders may be subtle in some areas",
          avoid: "Look for the continuous pink rim running along fascicle edges"
        },
        {
          mistake: "Thinking the entire nerve is one fascicle",
          why: "Most nerves contain multiple fascicles bundled together",
          avoid: "Count the number of perineurium-bounded bundles - that's your fascicle count"
        }
      ]
    },
    {
      name: "Fibrocytes",
      identificationTips: [
        "Dark blue/purple elongated nuclei within connective tissue layers",
        "Found in endoneurium, perineurium, and epineurium",
        "Produce and maintain collagen fibers",
        "Distinguished from Schwann nuclei by location in CT, not associated with myelin"
      ],
      commonMistakes: [
        {
          mistake: "Confusing fibrocytes with Schwann cells",
          why: "Both have elongated nuclei, but different locations",
          avoid: "Fibrocytes = in CT layers; Schwann cells = aligned with myelin sheaths"
        }
      ]
    },
    {
      name: "Adipocytes",
      identificationTips: [
        "Large white spaces (50-150 Î¼m) in epineurium OUTSIDE fascicles",
        "Much larger and more irregular than myelin spaces",
        "Variable sizes, not uniform like myelin",
        "Nucleus pushed to periphery (when visible), creating 'signet ring' appearance"
      ],
      commonMistakes: [
        {
          mistake: "Confusing adipocytes with myelin sheaths",
          why: "Both appear as white spaces in HE sections",
          avoid: "SIZE and LOCATION: Adipocytes 3× larger, OUTSIDE fascicles; Myelin small, INSIDE fascicles"
        },
        {
          mistake: "Not seeing adipocytes as cells",
          why: "Their lipid is dissolved, leaving only white space",
          avoid: "Remember: white space = lipid was there but dissolved during processing"
        }
      ]
    }
  ],

  criticalRelationships: [
    {
      title: "CNS-PNS Transition Zone (HIGH-YIELD EXAM TOPIC!)",
      content: "At the nerve roots where peripheral nerves enter/exit the CNS (dorsal and ventral roots), the three connective tissue layers transition directly to the three meningeal layers. This is a critical anatomical relationship tested on exams.",
      details: [
        "Endoneurium (innermost) â†' Pia mater (innermost meningeal layer)",
        "Perineurium (middle barrier layer) â†' Arachnoid mater (middle meningeal layer)",
        "Epineurium (outermost protective layer) â†' Dura mater (outermost meningeal layer)",
        "Transition occurs at CNS-PNS junction where nerve roots attach to spinal cord or brainstem",
        "Blood-nerve barrier (formed by perineurium tight junctions) is continuous with blood-brain barrier (formed by endothelial tight junctions)",
        "This continuity ensures protected pathways from brain/spinal cord to periphery"
      ],
      emphasis: "This parallel 3-layer protective system is ESSENTIAL to understand for neuroanatomy exams. The continuity ensures that nerve roots are protected as they transition from CNS to PNS. Disruption at this junction can cause specific clinical syndromes."
    },
    {
      title: "Longitudinal vs Cross Section Orientation (EXAM FAVORITE!)",
      content: "The same peripheral nerve appears dramatically different depending on section orientation. Recognizing orientation is critical for proper identification.",
      details: [
        "LONGITUDINAL (Slide 71): Wavy parallel fibers, linear myelin spaces, axons as continuous strands, Nodes of Ranvier visible",
        "CROSS (Slide 70): Fascicles show honeycomb pattern, circular myelin spaces, axons as central dots, no Nodes visible",
        "Wavy pattern in longitudinal = RELAXED nerve state, not pathology; provides reserve length for stretching",
        "Honeycomb pattern in cross section = classic diagnostic appearance for peripheral nerve identification",
        "Both show same 3 CT layers (ENDO-PERI-EPI), just different perspectives",
        "Nodes of Ranvier (gaps in myelin) only visible in longitudinal sections as interruptions in myelin track"
      ],
      emphasis: "Exam questions often test whether you can distinguish longitudinal from cross sections. WAVY = longitudinal is the key giveaway!"
    },
    {
      title: "Size Comparison: Myelin Spaces vs Adipocytes (CRITICAL DISTINCTION!)",
      content: "Both myelin sheaths and adipocytes appear as white spaces in HE sections because both contain lipids that are dissolved during tissue processing. However, they are easily distinguished by SIZE and LOCATION.",
      details: [
        "MYELIN SPACES: Small (5-15 Î¼m), uniform size, linear tracks flanking axons INSIDE fascicles",
        "ADIPOCYTES: Large (50-150 Î¼m, approximately 3-10× bigger), variable sizes, irregular spaces in EPINEURIUM OUTSIDE fascicles",
        "MYELIN: Has Schwann nucleus at periphery and central pink axon running through it",
        "ADIPOCYTES: Has nucleus pushed to edge (when visible), no central axon structure",
        "MYELIN: Forms organized linear pattern along nerve fibers in longitudinal sections",
        "ADIPOCYTES: Scattered irregularly in epineurium between fascicles",
        "LOCATION is the most reliable distinguishing feature: inside fascicles = myelin, outside fascicles = adipocytes"
      ],
      emphasis: "SIZE and LOCATION are the two critical features for distinguishing these structures. When confused, always ask: Is it inside or outside the fascicle? This single question resolves most identification challenges!"
    },
    {
      title: "Blood-Nerve Barrier vs Blood-Brain Barrier (HIGH-YIELD!)",
      content: "The perineurium forms a selective barrier controlling what enters nerve fascicles, analogous to the blood-brain barrier in the CNS.",
      details: [
        "PERINEURIUM contains specialized epithelioid cells connected by TIGHT JUNCTIONS",
        "These tight junctions create BLOOD-NERVE BARRIER preventing free diffusion",
        "Barrier protects nerve fibers from toxins, maintains stable ionic environment for conduction",
        "Unlike CNS (where BBB is in capillary endothelium), PNS barrier is in perineurium",
        "Barrier function is critical for saltatory conduction and nerve protection",
        "Clinical significance: Some drugs/toxins can't penetrate blood-nerve barrier, limiting therapeutic options and toxicity"
      ],
      emphasis: "Understanding barrier location (perineurium in PNS vs endothelium in CNS) is high-yield for both histology and pharmacology exams!"
    },
    {
      title: "Hierarchical Organization - Wrapping Pattern (EXAM FAVORITE!)",
      content: "Understanding the nesting order of connective tissue layers is essential for identification and comprehension of nerve structure-function relationships.",
      details: [
        "Level 1 (Innermost): Single axon + myelin + Schwann cell wrapped by ENDONEURIUM",
        "Level 2 (Middle): Bundle of multiple axons (fascicle) wrapped by PERINEURIUM",
        "Level 3 (Outermost): Bundle of multiple fascicles (whole nerve) wrapped by EPINEURIUM",
        "Each successive layer provides progressively stronger protection and support",
        "Analogy: Wire (axon) â†' Insulated wire (+ myelin) â†' Cable (fascicle) â†' Bundled cables (nerve trunk)",
        "This hierarchical organization allows individual axon protection while maintaining nerve trunk flexibility"
      ],
      emphasis: "This hierarchical pattern is your roadmap for nerve identification! Once you identify the perineurium, everything inside is a fascicle, and everything outside contributes to epineurium."
    }
  ],

  relationshipsSummary: [
    {
      title: "CNS-PNS Continuity (HIGH-YIELD!)",
      summary: "Nerve layers transition to meninges at roots: ENDO=Pia, PERI=Arachnoid, EPI=Dura",
      keyPoints: [
        "3-layer protection continuous from CNS to periphery",
        "Transition occurs at nerve root attachment sites",
        "Blood-nerve barrier continuous with blood-brain barrier",
        "Protects entire pathway from brain to target"
      ]
    },
    {
      title: "Longitudinal vs Cross Section (EXAM FAVORITE!)",
      summary: "Longitudinal = wavy parallel fibers; Cross = honeycomb circles. Same nerve, different view!",
      keyPoints: [
        "Wavy appearance = diagnostic for longitudinal orientation",
        "Honeycomb = diagnostic for cross section",
        "Nodes of Ranvier visible only in longitudinal",
        "Both show same 3 CT layers (ENDO-PERI-EPI)"
      ]
    },
    {
      title: "Myelin vs Adipocytes (CRITICAL!)",
      summary: "Both white spaces in HE, but SIZE + LOCATION different: myelin small/inside, adipocytes large/outside",
      keyPoints: [
        "Myelin 5-15 Î¼m, adipocytes 50-150 Î¼m (3-10× bigger)",
        "Myelin linear tracks INSIDE fascicles with axons",
        "Adipocytes irregular spaces OUTSIDE in epineurium",
        "Location is most reliable distinguishing feature"
      ]
    },
    {
      title: "Blood-Nerve Barrier (HIGH-YIELD!)",
      summary: "Perineurium tight junctions form barrier protecting fascicle microenvironment",
      keyPoints: [
        "Analogous to blood-brain barrier but in PNS",
        "Controls substance entry into fascicles",
        "Critical for stable conduction environment",
        "Clinical significance for drug/toxin penetration"
      ]
    }
  ],

  keyIdentifyingFeatures: [
    "WAVY PATTERN of nerve fibers - THE diagnostic feature for longitudinal sections; represents relaxed nerve state",
    "LINEAR WHITE MYELIN SPACES running parallel along axons (not circular like cross sections)",
    "CONTINUOUS PINK AXON STRANDS running centrally through myelin spaces (not dots)",
    "DISTINCT PINK PERINEURIUM forming continuous longitudinal borders around each fascicle",
    "ELONGATED SCHWANN NUCLEI aligned along myelin sheaths at regular intervals",
    "THREE CONNECTIVE TISSUE LAYERS visible: thin endoneurium, distinct perineurium rim, thick epineurium with adipocytes",
    "LARGE WHITE ADIPOCYTES in epineurium OUTSIDE fascicles (much larger than myelin spaces)",
    "PARALLEL FIBER ORGANIZATION - all fibers running in same direction within fascicles"
  ],

  comparisonWithOtherStains: [
    {
      stain: "Peripheral Nerve - Cross Section (HE) - Slide 70",
      differences: [
        "CROSS: Fascicles show HONEYCOMB pattern of circular myelin spaces vs LONGITUDINAL: Linear parallel myelin tracks",
        "CROSS: Axons appear as tiny PINK DOTS in center of circles vs LONGITUDINAL: Axons as continuous PINK STRANDS",
        "CROSS: NO wavy pattern, fibers cut perpendicular vs LONGITUDINAL: Characteristic WAVY appearance",
        "CROSS: Nodes of Ranvier NOT visible vs LONGITUDINAL: Nodes visible as interruptions in myelin",
        "CROSS: Easier to count individual nerve fibers vs LONGITUDINAL: Better for assessing nerve fiber length and continuity",
        "BOTH: Show same 3 CT layers (endoneurium, perineurium, epineurium) and CNS equivalents"
      ],
      whenToUse: "Cross sections are better for identifying and counting individual nerve fibers and seeing fascicle organization. Longitudinal sections are better for seeing Nodes of Ranvier, assessing fiber continuity, and understanding nerve architecture along its length. The wavy pattern in longitudinal sections is pathognomonic."
    },
    {
      stain: "Peripheral Nerve - Longitudinal Section (OsOâ‚„) - Slide 73",
      differences: [
        "OsOâ‚„: Myelin stains BLACK (lipids preserved and stained) vs HE: Myelin appears WHITE (lipids dissolved)",
        "OsOâ‚„: Axon appears UNSTAINED/WHITE (negative image) vs HE: Axon stains PINK (eosinophilic)",
        "OsOâ‚„: INVERTED contrast - black myelin with white axon vs HE: White myelin with pink axon",
        "OsOâ‚„: Superior for visualizing myelin architecture vs HE: Better for seeing overall tissue organization and CT layers",
        "OsOâ‚„: Nodes of Ranvier very obvious as WHITE GAPS in black myelin vs HE: Nodes subtle, seen as interruptions in white space",
        "BOTH: Show wavy fiber pattern characteristic of longitudinal sections",
        "BOTH: Show same 3 CT layers, but OsOâ‚„ emphasizes myelin while HE emphasizes CT structure"
      ],
      whenToUse: "OsOâ‚„ is specifically used when you want to visualize MYELIN ARCHITECTURE and lipid-rich structures (makes myelin black). HE is used for general tissue architecture showing nuclei, cytoplasm, and connective tissue organization. For exams, knowing that HE myelin = WHITE and OsOâ‚„ myelin = BLACK is critical!"
    }
  ],

  commonMistakes: [
    {
      mistake: "Confusing myelin linear spaces with blood vessels",
      why: "Both can appear as white/empty longitudinal spaces",
      avoid: "Myelin spaces are uniform, parallel, and associated with central pink axons. Blood vessels have walls, are irregular, and contain red blood cells. Myelin spaces are INSIDE fascicles; vessels are in epineurium."
    },
    {
      mistake: "Not recognizing the wavy pattern as normal",
      why: "Students may think waviness indicates pathology or poor fixation",
      avoid: "Wavy nerve fiber appearance is NORMAL in longitudinal sections of relaxed nerves. This provides reserve length for stretching during movement and is protective, not pathological."
    },
    {
      mistake: "Confusing adipocytes in epineurium with myelin sheaths",
      why: "Both appear as white spaces because lipids are dissolved in HE",
      avoid: "Use SIZE and LOCATION: Adipocytes are 3-10× LARGER (50-150 Î¼m vs 5-15 Î¼m) and located OUTSIDE fascicles in epineurium. Myelin is small, uniform, and INSIDE fascicles along axons."
    },
    {
      mistake: "Expecting to see myelin stained in HE sections",
      why: "Students may look for colored myelin",
      avoid: "In HE, myelin is a NEGATIVE IMAGE (white space) because lipids are extracted during processing. Myelin only stains with special lipid stains like osmium tetroxide (black) or luxol fast blue."
    },
    {
      mistake: "Not identifying the perineurium boundary",
      why: "May be subtle and mistaken for general connective tissue",
      avoid: "Look for the distinct pink RIM running continuously along fascicle edges. This is your landmark - once found, everything inside is the fascicle, everything outside contributes to epineurium."
    },
    {
      mistake: "Confusing Schwann cell nuclei with fibrocyte nuclei",
      why: "Both are elongated dark blue nuclei in longitudinal sections",
      avoid: "Schwann nuclei are ALIGNED ALONG MYELIN SHEATHS in regular pattern. Fibrocyte nuclei are scattered in connective tissue layers (endo/peri/epineurium) and not associated with individual fibers."
    },
    {
      mistake: "Thinking longitudinal and cross sections show different nerves",
      why: "They look very different (wavy vs honeycomb)",
      avoid: "It's the SAME structure, just cut in different planes. Like seeing a tube from the side (longitudinal) vs end-on (cross). Both show the same layers and components."
    }
  ],

  functionalContext: "Peripheral nerves transmit electrical signals bidirectionally between the CNS and body periphery. Motor axons carry efferent signals from CNS to muscles/glands. Sensory axons carry afferent signals from receptors to CNS. The three-layered connective tissue wrapping provides mechanical protection, vascular supply (vasa nervorum in epineurium), and barrier function (blood-nerve barrier in perineurium). The wavy configuration in longitudinal sections allows nerves to stretch up to 15-20% during limb movement without damage. Myelin sheaths (produced by Schwann cells) enable saltatory conduction, increasing conduction velocity 10-100×. Nodes of Ranvier (visible in longitudinal sections) are gaps where action potentials are regenerated.",

  clinicalCorrelations: [
    {
      condition: "Guillain-Barré Syndrome",
      relevance: "Autoimmune demyelination of peripheral nerves. Immune system attacks myelin sheaths (produced by Schwann cells), stripping myelin from axons. This eliminates saltatory conduction, causing progressive ascending weakness. In histology, would see loss of myelin (fewer white spaces), exposed axons, and inflammatory infiltrate in endoneurium. Recovery occurs as Schwann cells regenerate myelin."
    },
    {
      condition: "Peripheral Neuropathy (Diabetic)",
      relevance: "Chronic hyperglycemia damages both axons and microvasculature. Disrupts blood-nerve barrier function in perineurium, leading to nerve fiber degeneration. Affects endoneurial capillaries (vasa nervorum), causing ischemia. In histology, would see axon loss, myelin degeneration, thickened perineurium, and reduced nerve fiber density. Length-dependent pattern (longest nerves affected first) due to metabolic demands."
    },
    {
      condition: "Nerve Transection and Regeneration",
      relevance: "When peripheral nerves are cut, axons distal to injury undergo Wallerian degeneration (axon and myelin breakdown). Schwann cells proliferate and form regeneration tubes (bands of Büngner) to guide regrowing axons. In longitudinal sections, would see disrupted fiber continuity, Schwann cell proliferation, and eventually regenerating axon sprouts growing through Schwann tubes. The endoneurium provides the scaffold for regeneration. PNS can regenerate (unlike CNS) because Schwann cells support regrowth."
    },
    {
      condition: "Carpal Tunnel Syndrome",
      relevance: "Chronic compression of median nerve at wrist. Sustained pressure damages perineurium barrier function and compromises endoneurial blood flow, causing ischemia. In histology, would see nerve fiber compression, myelin degradation, and fibrosis of connective tissue layers. The epineurium becomes thickened and fibrotic. Demonstrates importance of mechanical protection by CT layers."
    },
    {
      condition: "Leprosy (Hansen's Disease)",
      relevance: "Mycobacterium leprae specifically infects Schwann cells in peripheral nerves, causing demyelination and sensory loss. Bacteria have tropism for cooler body areas and Schwann cells. In histology, would see Schwann cells packed with acid-fast bacilli, myelin loss, and granulomatous inflammation in perineurium and epineurium. One of the few bacterial infections targeting Schwann cells specifically."
    }
  ],

  identificationTips: [
    "FIRST: Look for the wavy pattern - this immediately confirms longitudinal section (vs honeycomb in cross section)",
    "SECOND: Identify fascicles by finding the pink perineurium border running longitudinally along bundle edges",
    "THIRD: Within fascicles, look for the repeating pattern: pink axon strand flanked by white linear myelin spaces",
    "FOURTH: Distinguish the three CT layers: thin barely-visible endoneurium between fibers, distinct pink perineurium rim around fascicles, thick epineurium with adipocytes outside fascicles",
    "Look for elongated Schwann nuclei aligned along myelin sheaths - these confirm you're seeing nerve fibers",
    "Scan for Nodes of Ranvier: brief interruptions in the linear myelin pattern where myelin is absent",
    "Large white spaces outside fascicles = adipocytes (3-10× bigger than myelin, in epineurium)",
    "Small uniform white linear spaces inside fascicles with central pink strand = myelin (in fascicles)",
    "If you see BLACK myelin instead of white spaces, you're looking at OsOâ‚„ stain (Slide 73), not HE!",
    "The wavy fiber pattern may vary in degree - more pronounced in relaxed nerves, less in stretched nerves",
    "Use the mnemonic 'WAVY = LONGITUDINAL, HONEYCOMB = CROSS' to instantly orient yourself",
    "Count fascicles by counting perineurium-bounded bundles - most nerves have multiple fascicles"
  ],

  examTips: [
    "Exam images often compare longitudinal vs cross sections of the same nerve - know the diagnostic differences!",
    "WAVY PATTERN is the #1 giveaway for longitudinal sections - mention this in your answer",
    "Remember: HE myelin = WHITE (negative image), OsOâ‚„ myelin = BLACK (positive staining)",
    "Be able to identify all three CT layers and state their CNS equivalents: ENDO=Pia, PERI=Arachnoid, EPI=Dura",
    "Know the blood-nerve barrier location (perineurium tight junctions) and its function",
    "Distinguish myelin from adipocytes using SIZE (adipocytes 3-10× bigger) and LOCATION (inside vs outside fascicles)",
    "Be prepared to identify Nodes of Ranvier in longitudinal sections (not visible in cross sections)",
    "Understand the hierarchical organization: axon â†' fascicle â†' nerve trunk",
    "Know clinical correlations: Guillain-Barré (demyelination), diabetic neuropathy (axon + vascular damage), nerve regeneration (Schwann cell role)",
    "If asked about conduction velocity, relate it to myelin presence (saltatory conduction is 10-100× faster)",
    "Be ready to explain WHY nerves are wavy (protective reserve length for stretching during movement)",
    "Remember that Schwann cells produce myelin in PNS (oligodendrocytes in CNS) - each Schwann cell myelinates ONE internode",
    "For structure-function questions: relate CT layers to protection, perineurium to blood-nerve barrier, myelin to conduction speed",
    "Longitudinal sections show fiber LENGTH and CONTINUITY; cross sections show ORGANIZATION and allow fiber COUNTING"
  ],

  ultraMinimalFacts: {
    staining: "HE: Myelin = WHITE (lipids dissolved), axon = PINK. Wavy = longitudinal!",
    layers: [
      "• ENDO = wraps 1 fiber (Pia)",
      "• PERI = wraps bundle (Arachnoid) - blood-nerve barrier!",
      "• EPI = wraps nerve (Dura) - has adipocytes"
    ],
    visualID: [
      "• WAVY parallel fibers = longitudinal section (diagnostic!)",
      "• Linear white spaces along axons = myelin tracks",
      "• Elongated nuclei along fibers = Schwann cells",
      "• Pink borders along bundles = perineurium",
      "• Large white outside = adipocytes (in epineurium)"
    ],
    cnsConnection: "ENDO→PERI→EPI = Pia→Arachnoid→Dura (continuous at nerve roots)",
    dontConfuse: [
      "• Myelin (small, linear, inside) ≠ Adipocytes (large, outside)",
      "• Longitudinal (wavy) ≠ Cross section (honeycomb circles)",
      "• HE myelin (white) ≠ OsO₄ myelin (black)",
      "• Schwann nuclei (along fibers) ≠ Fibrocyte nuclei (in CT)"
    ]
  }
};
const SLIDE_DATA_72 = {
  slideNumber: "72",
  name: "Peripheral Nerve - Cross Section (OsO₄)",
  section: "cross section",
  stain: "OsO₄",
  
  bigPicture: "OsO₄ makes myelin BLACK (vs white in HE) - best stain for visualizing lipid-rich myelin!",
  
  hierarchy: [
    "Axon → Fascicle → Whole Nerve",
    "↓ ENDO → PERI → EPI",
    "↓ (Pia) → (Arachnoid) → (Dura)"
  ],
  
  insideTheFascicles: [
    {
      structure: "Myelin sheath (stained BLACK)",
      description: "Dark black rings around axons; osmium binds to lipids revealing true myelin architecture"
    },
    {
      structure: "Axon (negative image)",
      description: "White/pale center dot inside black myelin ring; unstained by osmium"
    },
    {
      structure: "Schwann cell nucleus",
      description: "Small dark nucleus at periphery of black myelin ring; produces and maintains myelin"
    },
    {
      structure: "Endoneurium",
      description: "Delicate connective tissue between myelinated fibers; appears pale between black rings"
    },
    {
      structure: "Black ring pattern",
      description: "Characteristic 'donuts' or 'target' appearance with white centers and thick black walls"
    }
  ],
  
  stainingInfo: {
    technique: "OsO₄ (Osmium Tetroxide) - Heavy metal lipid stain",
    description: "Osmium tetroxide is a fixative and stain that binds irreversibly to lipids, especially unsaturated fatty acids in phospholipid membranes. Unlike routine HE processing where lipids dissolve, osmium preserves and stains lipid-rich structures black.",
    whatItStainsInThisSlide: [
      "Myelin sheaths → BLACK (dark, electron-dense rings)",
      "Axons → UNSTAINED (appear white/pale in center of myelin rings)",
      "Schwann cell nuclei → Dark gray to black (contain chromatin)",
      "Endoneurium → Pale gray (minimal staining)",
      "Perineurium → Light brown/tan (connective tissue)",
      "Epineurium → Light brown/tan with embedded structures",
      "Adipocytes → BLACK (lipid-rich; can confuse with myelin if not careful about location)",
      "Blood vessels → Pale with dark nuclei of endothelial cells"
    ],
    keyEmphasis: "OsO₄ is THE gold standard for myelin visualization because it preserves lipids during fixation and stains them intensely black, revealing the true myelin sheath architecture. This is the opposite of HE where lipids dissolve leaving white 'negative images.' The stark BLACK myelin rings against pale background make nerve fiber organization crystal clear and allow accurate assessment of myelination status, myelin thickness variations, and detection of demyelinating pathologies."
  },

  layers: [
    {
      name: "Endoneurium",
      level: "Innermost layer (Level 1)",
      wraps: "Individual nerve fiber (single axon + myelin sheath + Schwann cell)",
      composition: "Delicate loose connective tissue with reticular fibers (Type III collagen), scattered fibroblasts, and capillaries",
      appearance: "Very thin pale tissue barely visible between individual black myelin rings within a fascicle. Appears as subtle pale spaces separating the dense black donuts.",
      contains: "Endoneurial capillaries (part of blood-nerve barrier), fibroblasts, reticular fibers, tissue fluid bathing nerve fibers",
      cnsEquivalent: "Pia mater (direct transition at CNS-PNS junction at nerve roots)",
      function: "Provides microenvironment for individual nerve fibers, supports axon nutrition and metabolic exchange, maintains ionic balance critical for action potential propagation",
      quickID: "Thinnest pale layer between black myelin rings inside bundles"
    },
    {
      name: "Perineurium",
      level: "Middle layer (Level 2)",
      wraps: "Fascicle (bundle of multiple nerve fibers)",
      composition: "2-6 concentric layers of specialized epithelioid perineural cells (modified fibroblasts) connected by tight junctions, each layer surrounded by basement membrane",
      appearance: "Distinct light brown/tan rim encircling each fascicle, appearing as a smooth, continuous boundary around clusters of black myelin rings. More prominent than endoneurium.",
      contains: "Perineural cells with tight junctions forming diffusion barrier, basement membrane surrounding each cell layer, occasional fibroblasts, perineurial space",
      cnsEquivalent: "Arachnoid mater (transition at nerve roots)",
      function: "Forms blood-nerve barrier controlling diffusion of substances into/out of fascicle, maintains stable ionic microenvironment for nerve conduction, protects against mechanical stress, prevents entry of toxins and pathogens",
      quickID: "Light rim surrounding each cluster of black rings - the fascicle border"
    },
    {
      name: "Epineurium",
      level: "Outermost layer (Level 3)",
      wraps: "Entire nerve (multiple fascicles together)",
      composition: "Dense irregular connective tissue with thick collagen bundles, abundant adipose tissue, fibroblasts, blood vessels (vasa nervorum), and lymphatics",
      appearance: "Thick pale brown/tan connective tissue surrounding and separating fascicles. Contains large BLACK adipocytes (lipid stains with OsO₄!) and blood vessels. Forms the outermost coat and fills interfascicular spaces.",
      contains: "Large blood vessels (vasa nervorum providing arterial supply), lymphatics, abundant adipose tissue (appears BLACK like myelin but much larger), nervi nervorum (nerves innervating nerve sheaths), thick collagen bundles, fibroblasts",
      cnsEquivalent: "Dura mater (continuous transition at nerve roots)",
      function: "Mechanical protection of entire nerve, provides rich vascular supply via vasa nervorum, allows nerve mobility and flexibility, cushioning between fascicles, protects from compression injury",
      quickID: "Thickest layer with LARGE black adipocytes, surrounds entire nerve and fills spaces between fascicles"
    }
  ],

  criticalRelationships: [
    {
      title: "OsO₄ vs HE: The Myelin Reversal (EXAM FAVORITE!)",
      content: "Understanding how the same structure appears completely opposite in different stains is critical for slide identification:",
      details: [
        "HE (Slide 70): Myelin = WHITE (negative image) - lipids dissolved during processing",
        "OsO₄ (Slide 72): Myelin = BLACK (positive staining) - lipids preserved and stained",
        "HE: Axon appears as tiny pink dot",
        "OsO₄: Axon appears as white/unstained center",
        "The 'reversal' happens because OsO₄ is both fixative AND stain - preserves what HE destroys",
        "OsO₄ allows accurate measurement of myelin thickness and detection of demyelination",
        "Clinical importance: OsO₄ reveals pathological changes in myelin (demyelinating diseases like MS, Guillain-Barré)"
      ],
      emphasis: "This is THE classic comparison question on exams! If you see BLACK rings = OsO₄. If you see WHITE spaces = HE. Don't confuse them!"
    },
    {
      title: "Size Comparison: Myelin vs Adipocytes - Both BLACK in OsO₄! (HIGH-YIELD!)",
      content: "Both myelin sheaths AND adipocytes stain black with OsO₄ (both are lipid-rich), but size and location distinguish them:",
      details: [
        "MYELIN: Small black rings (5-15 μm), uniform size, INSIDE fascicles, has white axon center",
        "ADIPOCYTES: Large black circles (50-150 μm, up to 10× bigger!), variable sizes, in EPINEURIUM OUTSIDE fascicles",
        "MYELIN: Forms regular honeycomb pattern, densely packed",
        "ADIPOCYTES: Scattered irregularly, not organized pattern",
        "LOCATION is key: Myelin inside fascicle boundaries, Adipocytes in connective tissue between fascicles",
        "SIZE difference is dramatic: adipocytes are 3-10× larger than myelin rings",
        "Both have peripheral nucleus, but adipocyte nucleus is at edge of large circle, myelin has central white axon"
      ],
      emphasis: "SIZE and LOCATION are your two critical discriminators! Don't let the black staining fool you - look WHERE it is and HOW BIG it is!"
    },
    {
      title: "CNS-PNS Transition Zone (HIGH-YIELD EXAM TOPIC!)",
      content: "At the nerve roots where peripheral nerves enter/exit the CNS, the three connective tissue layers transition directly to the three meningeal layers - a critical concept for understanding nerve root pathology:",
      details: [
        "Endoneurium → Pia mater (innermost, delicate vascular layer)",
        "Perineurium → Arachnoid mater (middle, barrier function with tight junctions)",
        "Epineurium → Dura mater (outermost, tough protective layer)",
        "Transition zone occurs at CNS-PNS junction at nerve roots (cauda equina, brachial plexus roots)",
        "Blood-nerve barrier (perineurium) continuous with blood-brain barrier function",
        "Clinical: Nerve root compression affects this transition zone (herniated disc, radiculopathy)",
        "The parallel 3-layer system ensures continuous protection from CNS to periphery"
      ],
      emphasis: "This parallel 3-layer protective system is ESSENTIAL exam knowledge. The continuity ensures protected pathway from brain/spinal cord to peripheral targets!"
    },
    {
      title: "Hierarchical Organization - The Wrapping Pattern (EXAM FAVORITE!)",
      content: "Understanding the nesting order from inside-out is your roadmap for identifying all nerve structures:",
      details: [
        "Level 1 (Individual fiber): Single myelinated axon wrapped by ENDONEURIUM",
        "Level 2 (Fascicle): Bundle of many fibers wrapped together by PERINEURIUM",
        "Level 3 (Whole nerve): Multiple fascicles wrapped together by EPINEURIUM",
        "Each level provides progressively stronger protection",
        "Think of it like: Wire → Cable → Bundled cables with outer sheath",
        "The perineurium is THE anchor structure - once you find those boundaries, you can identify everything else",
        "Cross-section view reveals this organization perfectly - concentric layers of protection"
      ],
      emphasis: "Master this hierarchical pattern and nerve identification becomes systematic! Start with fascicle boundaries (perineurium), then work inward and outward."
    }
  ],

  relationshipsSummary: [
    {
      title: "OsO₄ vs HE Myelin Appearance (HIGH-YIELD!)",
      summary: "OsO₄ stains myelin BLACK (lipids preserved), HE shows WHITE spaces (lipids dissolved) - classic reversal pattern",
      keyPoints: [
        "OsO₄: myelin = black rings, axon = white center",
        "HE: myelin = white spaces, axon = pink dot",
        "OsO₄ reveals true myelin architecture for pathology",
        "Both show same 3-layer organization (Endo-Peri-Epi)"
      ]
    },
    {
      title: "Myelin vs Adipocytes - Both Black! (HIGH-YIELD!)",
      summary: "Size + location distinguish them: myelin = small (5-15μm) inside fascicles, adipocytes = large (50-150μm) outside",
      keyPoints: [
        "3-10× size difference is dramatic",
        "Myelin = inside bundles, uniform honeycomb",
        "Adipocytes = in epineurium between fascicles",
        "Both black due to lipid content"
      ]
    },
    {
      title: "CNS-PNS Layer Transitions (HIGH-YIELD!)",
      summary: "Three nerve layers = three meninges: Endo→Pia, Peri→Arachnoid, Epi→Dura at nerve roots",
      keyPoints: [
        "Continuous protection from CNS to periphery",
        "Blood-nerve barrier ↔ Blood-brain barrier",
        "Transition zone at nerve roots (exam favorite)",
        "Same 3-layer principle throughout nervous system"
      ]
    }
  ],

  keyIdentifyingFeatures: [
    "BLACK myelin rings throughout fascicles (opposite of white in HE) - pathognomonic for OsO₄",
    "White/unstained axons in center of black rings creating 'target' or 'donut' pattern",
    "Distinct light brown/tan perineurium rim around each fascicle bundle",
    "Large black adipocytes in epineurium (MUCH bigger than myelin rings, 50-150 μm vs 5-15 μm)",
    "Regular honeycomb pattern of uniform black rings within fascicles",
    "Clear fascicle organization with multiple bundles separated by epineurium",
    "Small dark Schwann cell nuclei at periphery of black myelin rings"
  ],

  comparisonWithOtherStains: {
    description: "Peripheral nerve appears dramatically different with OsO₄ versus HE staining due to lipid preservation:",
    comparisons: [
      {
        feature: "Myelin sheath appearance",
        thisStain: "BLACK rings (osmium binds to and stains lipids)",
        otherStain: "WHITE spaces in HE (lipids dissolved, negative image)",
        significance: "Complete reversal - most important distinguishing feature"
      },
      {
        feature: "Axon visualization",
        thisStain: "White/pale unstained center of black ring",
        otherStain: "Tiny pink dot in center of white space in HE",
        significance: "Axon contrast reversed but central position maintained"
      },
      {
        feature: "Overall appearance",
        thisStain: "Black 'donuts' or 'targets' on pale background",
        otherStain: "White 'honeycomb' with pink centers in HE",
        significance: "Dramatic visual reversal aids identification"
      },
      {
        feature: "Myelin thickness assessment",
        thisStain: "Accurate - preserved and visible as black ring width",
        otherStain: "Inaccurate - dissolved during processing in HE",
        significance: "OsO₄ allows quantitative myelin evaluation"
      },
      {
        feature: "Adipocytes",
        thisStain: "BLACK like myelin (lipid-rich) but much LARGER and OUTSIDE fascicles",
        otherStain: "WHITE like myelin in HE but much LARGER and OUTSIDE fascicles",
        significance: "Size and location distinguish regardless of stain"
      },
      {
        feature: "Connective tissue layers",
        thisStain: "Light brown/tan (Peri and Epi), pale (Endo)",
        otherStain: "Pink (all three layers) in HE",
        significance: "Both stains show same 3-layer organization"
      },
      {
        feature: "Clinical utility",
        thisStain: "Best for evaluating myelination status, detecting demyelination",
        otherStain: "Better for general architecture and nuclei in HE",
        significance: "OsO₄ is gold standard for myelin pathology"
      }
    ]
  },

  commonMistakes: [
    {
      mistake: "Confusing BLACK myelin rings with BLACK adipocytes",
      why: "Both are lipid-rich and stain black with osmium",
      correction: "Check SIZE (myelin 5-15 μm, adipocytes 50-150 μm, 3-10× difference) and LOCATION (myelin inside fascicles forming honeycomb, adipocytes in epineurium between fascicles)",
      examTip: "Always ask: 'Is it inside or outside the fascicle boundary?' and 'How big is it compared to neighbors?'"
    },
    {
      mistake: "Thinking OsO₄ is just 'another way to see the same thing as HE'",
      why: "Students don't appreciate the complete reversal of myelin appearance",
      correction: "OsO₄ and HE show OPPOSITE images of myelin - black vs white. This reversal is due to lipid preservation vs dissolution. OsO₄ reveals TRUE myelin architecture while HE shows where myelin WAS before processing dissolved it.",
      examTip: "On exams, if you see black rings = OsO₄, white spaces = HE. Master this reversal!"
    },
    {
      mistake: "Confusing the white axon center in OsO₄ with the white myelin space in HE",
      why: "Both have 'white' structures but mean completely different things",
      correction: "OsO₄: White = unstained AXON (small central dot inside black ring). HE: White = dissolved MYELIN space (ring/halo around pink axon). Context determines meaning!",
      examTip: "Look at the entire structure - black ring with white center = OsO₄. White ring with pink center = HE."
    },
    {
      mistake: "Missing the perineurium boundary and not recognizing fascicles",
      why: "Focusing only on the dramatic black myelin rings",
      correction: "ALWAYS identify the light brown/tan perineurium rims first - these define fascicle boundaries and organize everything else. Once you find fascicle borders, you can systematically identify layers inside and outside.",
      examTip: "Start identification with: 1) Find perineurium rims, 2) Identify fascicles, 3) Look at myelin inside, 4) Look at epineurium outside"
    },
    {
      mistake: "Thinking all structures should be black in OsO₄",
      why: "The name 'osmium stain' suggests everything gets stained",
      correction: "OsO₄ is selective for LIPIDS. Only lipid-rich structures (myelin, adipocytes) stain black. Axons, connective tissue, and most other structures remain pale or light brown. The contrast between black lipid structures and pale everything else is what makes OsO₄ so useful.",
      examTip: "Black = lipids (myelin, fat). Everything else = pale to light brown. Use this contrast!"
    }
  ],

  clinicalCorrelations: [
    {
      condition: "Demyelinating Diseases (Multiple Sclerosis, Guillain-Barré Syndrome)",
      relevance: "OsO₄ staining is the gold standard for detecting and quantifying demyelination. In MS and GBS, myelin sheaths are damaged by autoimmune attack. OsO₄ reveals: 1) Thinning or absence of black myelin rings, 2) Irregular myelin thickness (patchy demyelination), 3) Exposed axons without black rings, 4) Macrophage infiltration with debris. Unlike HE which only shows 'missing white spaces,' OsO₄ directly visualizes myelin pathology.",
      examRelevance: "High-yield: 'Which stain would best reveal demyelination?' Answer: OsO₄. Understand why: it stains myelin directly, not as negative image."
    },
    {
      condition: "Peripheral Neuropathy (Diabetic, Toxic, Hereditary)",
      relevance: "Peripheral neuropathies involve nerve fiber damage and demyelination. OsO₄ allows assessment of: 1) Myelin sheath integrity (black ring continuity), 2) Myelin thickness uniformity (should be consistent), 3) Axon-to-myelin ratio, 4) Presence of remyelination (thinner black rings on regenerating fibers). The dramatic black-on-pale contrast makes even subtle myelin abnormalities visible.",
      examRelevance: "Clinical correlation: 'Why is OsO₄ preferred for nerve biopsy evaluation?' Because it reveals true myelin architecture and pathological changes invisible with routine staining."
    },
    {
      condition: "Wallerian Degeneration (Nerve Injury Distal to Cut)",
      relevance: "After peripheral nerve transection, the distal segment undergoes Wallerian degeneration where myelin breaks down. OsO₄ reveals progression: 1) Early: fragmented black rings (myelin breaking), 2) Middle: granular black debris (myelin breakdown), 3) Late: absence of black rings (complete degradation). Macrophages phagocytosing black myelin debris are visible. This progression is critical for timing nerve injuries.",
      examRelevance: "Forensic significance: OsO₄ stages of degeneration can help time nerve injuries. Understanding the sequence is testable."
    },
    {
      condition: "Compression Neuropathies (Carpal Tunnel, Radiculopathy)",
      relevance: "Chronic compression damages both myelin and axons. OsO₄ shows: 1) Myelin thinning (thinner black rings) at compression site, 2) Myelin discontinuity, 3) Fascicle distortion, 4) Increased connective tissue (pale areas) between fibers. The blood-nerve barrier (perineurium) may be compromised, visible as irregular fascicle boundaries.",
      examRelevance: "Clinical scenario: 'Patient with chronic carpal tunnel - what histological changes expected?' Segmental demyelination visible with OsO₄."
    }
  ],

  functionalContext: "OsO₄ staining serves both diagnostic and research purposes. Diagnostically, it's the gold standard for peripheral nerve biopsies to evaluate suspected neuropathies, allowing quantitative assessment of myelinated fiber density, myelin thickness distribution, and detection of demyelinating vs axonal pathologies. In research, OsO₄ is essential for electron microscopy preparation (primary fixative) and for studying myelin development, regeneration after injury, and effects of neurotoxins. The stain's ability to preserve and visualize lipid-rich myelin makes it irreplaceable for understanding normal nerve structure and pathological changes. The dramatic black myelin visualization allows even inexperienced observers to identify nerve fibers and assess myelination status, making it valuable for teaching and medical education.",

  identificationTips: [
    "Start with the big picture: Multiple circular fascicles with BLACK rings inside = peripheral nerve with OsO₄",
    "Confirm stain type: BLACK myelin rings (not white) = OsO₄ confirmed. If white = HE, not this slide!",
    "Identify fascicle boundaries: Look for light brown/tan perineurium rims around clusters of black rings - these define fascicles",
    "Inside fascicles: Dense regular array of uniform BLACK rings (myelin) with white centers (axons) creating honeycomb/target pattern",
    "Between fascicles: Thick pale brown epineurium containing LARGE black adipocytes (much bigger than myelin, 3-10× size difference)",
    "Size comparison is key: Small uniform black rings (5-15 μm) inside bundles = myelin. Large variable black circles (50-150 μm) outside bundles = adipocytes",
    "Look for Schwann cell nuclei: Small dark nuclei at periphery of black myelin rings (at 'edge of donut')",
    "The endoneurium is subtle: Very thin pale spaces between black myelin rings within fascicles",
    "Use the reversal concept: Compare mentally with HE - everything that was white is now black, everything that was pink is now pale/white",
    "Systematic approach: 1) Confirm OsO₄ (black myelin), 2) Find fascicles (perineurium), 3) Identify layers (Endo-Peri-Epi), 4) Distinguish myelin from fat (size + location)"
  ],

  examTips: [
    "Master the OsO₄ vs HE comparison - this is THE most common exam question about peripheral nerve. If shown two images and asked 'What's the difference?', answer: 'Staining method - OsO₄ stains myelin black vs HE where myelin appears white (negative image).'",
    "Size comparison is testable: 'Identify structure X' where X is either myelin or adipocyte (both black). Answer based on: Size (5-15 μm vs 50-150 μm) and Location (inside vs outside fascicles).",
    "Know the clinical utility: 'Which stain best for evaluating demyelination?' Answer: OsO₄, because it directly stains myelin and reveals true architecture (not negative image).",
    "CNS-PNS transitions are high-yield: Be ready to identify the three layers and state their CNS equivalents (Endo=Pia, Peri=Arachnoid, Epi=Dura).",
    "Understand the 'why' behind the reversal: OsO₄ is both fixative AND stain - it PRESERVES lipids and stains them. HE processing DISSOLVES lipids leaving empty spaces. Exam questions test conceptual understanding, not just recognition.",
    "Blood-nerve barrier formation: Know that PERINEURIUM forms this barrier with tight junctions (not the blood vessels themselves). Exam favorite: 'Which layer forms blood-nerve barrier?'",
    "Hierarchical organization is testable: Be able to describe the nesting pattern from inside-out or draw a labeled diagram showing Axon → Endoneurium → Fascicle → Perineurium → Nerve → Epineurium.",
    "Practical identification on exam: If given unlabeled image with black rings, systematically identify: 1) Stain (OsO₄), 2) Tissue (peripheral nerve), 3) Section type (cross vs longitudinal), 4) Layers (Endo-Peri-Epi), 5) Structures (myelin, axons, adipocytes).",
    "Common trap question: 'Why do adipocytes appear black in this preparation?' Answer must mention lipid content AND osmium's affinity for lipids, then note size/location difference from myelin.",
    "Integration with pathology: Understand that OsO₄ is used clinically in nerve biopsies for neuropathy diagnosis - this bridges basic science to clinical practice (high-yield for integrated exams)."
  ],

  ultraMinimalFacts: {
    staining: "OsO₄: Myelin = BLACK (lipids preserved!), opposite of HE. Axon = white center",
    layers: [
      "• ENDO = wraps 1 fiber (Pia)",
      "• PERI = wraps bundle (Arachnoid) - blood-nerve barrier!",
      "• EPI = wraps nerve (Dura)"
    ],
    visualID: [
      "• BLACK rings inside fascicles = myelin (diagnostic!)",
      "• White centers in black rings = axons",
      "• Light rim around bundles = perineurium",
      "• LARGE black outside fascicles = adipocytes (10× bigger)"
    ],
    cnsConnection: "Endo → Peri → Epi = Pia → Arachnoid → Dura (transition at nerve roots)",
    dontConfuse: [
      "• Myelin (small, inside) ≠ Adipocyte (large, outside) - both black!",
      "• OsO₄ myelin (BLACK rings) ≠ HE myelin (WHITE spaces)",
      "• White axon center (OsO₄) ≠ White myelin space (HE)"
    ]
  }
};
const SLIDE_DATA_73 = {
  slideNumber: "73",
  name: "Peripheral Nerve - Longitudinal Section (OsO₄)",
  section: "longitudinal section",
  stain: "OsO₄",
  
  bigPicture: "Longitudinal nerve with BLACK myelin tubes interrupted by white node gaps!",
  
  hierarchy: [
    "Axon → Fascicle → Whole Nerve",
    "↓ ENDO → PERI → EPI",
    "↓ (Pia) → (Arachnoid) → (Dura)"
  ],
  
  insideTheFascicles: [
    {
      structure: "Axon (negative image)",
      description: "Central pale/unstained fiber running longitudinally; appears white because osmium doesn't stain proteins well"
    },
    {
      structure: "Myelin sheath (BLACK)",
      description: "Dark brown/black segmented tubes surrounding axons; osmium stains lipids creating positive image"
    },
    {
      structure: "Node of Ranvier",
      description: "DIAGNOSTIC white gaps interrupting black myelin at regular intervals; exposed axolemma where myelin is absent"
    },
    {
      structure: "Schwann cell nucleus",
      description: "Dark elongated nucleus at periphery of myelin sheath along fiber length"
    },
    {
      structure: "Schmidt-Lanterman clefts",
      description: "Oblique light lines within dark myelin segments; cytoplasmic channels of Schwann cells"
    }
  ],
  
  stainingInfo: {
    technique: "OsO₄ (Osmium Tetroxide)",
    description: "Heavy metal stain with high affinity for unsaturated lipids, particularly phospholipids in myelin sheaths. Osmium binds to carbon-carbon double bonds in fatty acids, causing reduction to black metallic osmium.",
    whatItStainsInThisSlide: [
      "Myelin sheath → BLACK/dark brown (high lipid content; diagnostic positive image)",
      "Axoplasm → UNSTAINED/pale (negative image; proteins don't bind osmium)",
      "Node of Ranvier → WHITE GAPS (absence of myelin creates diagnostic interruptions)",
      "Schwann cell nuclei → Dark/black (chromatin)",
      "Endoneurium → Light tan/pale (minimal lipid)",
      "Perineurium → Tan/light brown (multiple cell layers)",
      "Epineurium → Tan with BLACK adipocytes (fat cells stain intensely black)",
      "Schmidt-Lanterman clefts → Pale lines within dark myelin (cytoplasmic channels)"
    ],
    keyEmphasis: "OsO₄ specifically demonstrates the SEGMENTED nature of myelination in longitudinal view, making nodes of Ranvier dramatically visible as regular white gaps between black myelin segments. This is the gold standard for visualizing myelin continuity, nodes of Ranvier location, and assessing myelination quality - critical for diagnosing demyelinating diseases."
  },

  layers: [
    {
      name: "Endoneurium",
      level: "Innermost layer (Level 1)",
      wraps: "Individual myelinated nerve fiber (axon + myelin + Schwann cell)",
      composition: "Delicate loose connective tissue with reticular fibers (type III collagen), fibroblasts, and rich capillary network oriented longitudinally along nerve fibers",
      appearance: "Very thin pale tan layer closely surrounding individual black myelin tubes; barely visible between nerve fibers in longitudinal sections",
      contains: "Individual myelinated axons with segmented black myelin, Schwann cells, endoneurial capillaries, fibroblasts, endoneurial fluid",
      cnsEquivalent: "Pia mater",
      function: "Provides metabolic support and microenvironment for nerve fibers; facilitates nutrient exchange; provides scaffold for axon regeneration after injury",
      quickID: "Thinnest pale layer hugging individual black myelin tubes longitudinally"
    },
    {
      name: "Perineurium",
      level: "Middle layer (Level 2)",
      wraps: "Fascicle (bundle of multiple myelinated nerve fibers)",
      composition: "5-10 concentric layers of flattened perineurial cells connected by tight junctions, alternating with collagen layers; forms epithelioid cellular barrier",
      appearance: "Distinct tan multi-layered sheath encircling bundles of longitudinal black myelin segments; appears as laminated border in longitudinal view",
      contains: "Multiple perineurial cell layers with tight junctions (blood-nerve barrier), basement membranes, occasional fibroblasts",
      cnsEquivalent: "Arachnoid mater",
      function: "Blood-nerve barrier via tight junctions; maintains endoneurial fluid pressure and ionic homeostasis; mechanical protection of fascicles; controls molecular access to nerve fibers",
      quickID: "Multi-layered tan rim surrounding bundles of longitudinal black fibers"
    },
    {
      name: "Epineurium",
      level: "Outermost layer (Level 3)",
      wraps: "Entire peripheral nerve (all fascicles together)",
      composition: "Dense irregular connective tissue with thick type I collagen bundles, fibroblasts, adipocytes, blood vessels (vasa nervorum), lymphatics, running longitudinally",
      appearance: "Thick tan outer layer surrounding and separating fascicles; contains prominent BLACK adipocytes due to osmium staining lipid-filled fat cells",
      contains: "Vasa nervorum (arterial and venous blood supply), lymphatic vessels, adipose tissue (stains black), collagen bundles, nervi nervorum",
      cnsEquivalent: "Dura mater",
      function: "Mechanical cushioning and protection; houses vasa nervorum for blood supply; allows nerve trunk mobility during movement; energy reservoir (adipose tissue)",
      quickID: "Thickest outer layer with scattered large BLACK fat cells around nerve"
    }
  ],

  criticalRelationships: [
    {
      title: "OsO₄ vs HE: Opposite Myelin Appearance (HIGH-YIELD!)",
      content: "The SAME peripheral nerve looks completely opposite depending on stain - this is the most tested concept!",
      details: [
        "OsO₄ (Slides 72-73): Myelin = BLACK (positive image) because osmium PRESERVES and STAINS lipids",
        "HE (Slides 70-71): Myelin = WHITE spaces (negative image) because lipids DISSOLVE during processing",
        "OsO₄: Axon appears PALE/unstained (negative image of axon)",
        "HE: Axon appears PINK (positive image with eosin)",
        "Nodes of Ranvier: DRAMATICALLY visible in OsO₄ as white gaps; difficult to see in HE",
        "Both show identical 3-layer structure (endo/peri/epi), only difference is myelin visualization",
        "Rule: BLACK myelin = OsO₄; WHITE spaces = HE"
      ],
      emphasis: "If you see dark myelin tubes, you're looking at osmium stain. If you see honeycomb white spaces, you're looking at HE. This distinction appears on every exam!"
    },
    {
      title: "Nodes of Ranvier: Structure and Significance (EXAM FAVORITE!)",
      content: "Nodes are THE defining feature of longitudinal nerve sections and essential for nerve physiology:",
      details: [
        "APPEARANCE: Regular WHITE GAPS interrupting black myelin tubes at ~1mm intervals (0.2-2mm)",
        "COMPOSITION: Exposed axolemma with extremely high density of voltage-gated Na⁺ channels (1000-2000/μm²)",
        "FUNCTION: Saltatory conduction - action potential JUMPS node-to-node = 50× faster than unmyelinated",
        "In longitudinal OsO₄: Appear as dramatic white constrictions creating segmented appearance",
        "In cross-section: NOT visible (you'd need serial sections to catch the node)",
        "Clinical: Demyelinating diseases (MS, GBS) disrupt nodes → conduction velocity drops dramatically",
        "Regeneration: Nodes reform during remyelination, but spacing may be abnormal"
      ],
      emphasis: "Nodes of Ranvier are ONLY clearly visible in LONGITUDINAL sections with OsO₄ stain. Their presence confirms you're looking at Slide 73, not Slide 72 (cross-section)!"
    },
    {
      title: "CNS-PNS Meningeal Equivalents (HIGH-YIELD!)",
      content: "The 3 nerve layers are functionally and embryologically equivalent to the 3 CNS meninges:",
      details: [
        "ENDONEURIUM = PIA MATER: Both are innermost, delicate, highly vascularized",
        "PERINEURIUM = ARACHNOID MATER: Both form selective BARRIERS (blood-nerve vs blood-CSF)",
        "EPINEURIUM = DURA MATER: Both are outermost, tough, protective",
        "Transition zone: At CNS-PNS junction (nerve root), layers literally TRANSFORM into each other",
        "Blood-nerve barrier (perineurium) = Blood-brain barrier (brain capillaries)",
        "Both systems protect neural tissue but allow controlled nutrient access",
        "Clinical: Tumor spread can follow these planes; infections respect these barriers"
      ],
      emphasis: "Understanding PNS-CNS equivalency helps predict pathology spread patterns and explains why certain infections/tumors behave differently in peripheral nerves vs CNS!"
    },
    {
      title: "Adipocytes vs Myelin: Both BLACK in OsO₄ (EXAM TRAP!)",
      content: "Don't confuse these two structures - both stain black but have completely different locations and functions:",
      details: [
        "MYELIN: Inside fascicles, organized as parallel longitudinal tubes, ~15μm diameter, segmented with nodes",
        "ADIPOCYTES: In EPINEURIUM only (never inside fascicles), large spherical cells (50-150μm), scattered distribution",
        "MYELIN: Functional (insulation for saltatory conduction)",
        "ADIPOCYTES: Structural (cushioning, energy storage)",
        "Key distinction: LOCATION - myelin inside bundles, fat outside bundles",
        "Size matters: Myelin tubes much smaller and uniform; adipocytes variable and large",
        "Pattern: Myelin organized in parallel arrays; adipocytes scattered randomly"
      ],
      emphasis: "LOCATION is key! If the black structure is INSIDE a fascicle running longitudinally = myelin. If it's OUTSIDE fascicles in epineurium = adipocyte. This is tested frequently!"
    }
  ],

  relationshipsSummary: [
    {
      title: "OsO₄ vs HE Staining (HIGH-YIELD!)",
      summary: "Same nerve, opposite myelin appearance: OsO₄ = BLACK tubes (lipids preserved), HE = WHITE spaces (lipids dissolved)",
      keyPoints: [
        "BLACK myelin = OsO₄ positive image",
        "WHITE myelin = HE negative image",
        "Nodes visible only in OsO₄ longitudinal",
        "Identify stain by myelin color!"
      ]
    },
    {
      title: "Nodes of Ranvier Function (HIGH-YIELD!)",
      summary: "White gaps in BLACK myelin = nodes; saltatory conduction site with clustered Na⁺ channels",
      keyPoints: [
        "Only visible in LONGITUDINAL sections",
        "Regular white gaps (~1mm intervals)",
        "Enable 50× faster conduction",
        "Lost in demyelinating diseases"
      ]
    },
    {
      title: "CNS Meningeal Equivalents (HIGH-YIELD!)",
      summary: "Nerve layers = meninges: Endo=Pia, Peri=Arachnoid (barrier!), Epi=Dura",
      keyPoints: [
        "Perineurium = blood-nerve barrier",
        "Layers transform at nerve roots",
        "Same protective strategy",
        "Predicts pathology spread patterns"
      ]
    },
    {
      title: "Location Distinguishes Structures (HIGH-YIELD!)",
      summary: "Myelin vs adipocytes: Both BLACK but myelin INSIDE fascicles, adipocytes in EPINEURIUM outside",
      keyPoints: [
        "Inside fascicles = myelin tubes",
        "Outside fascicles = fat cells",
        "Size: myelin small, fat large",
        "Don't confuse based on color alone!"
      ]
    }
  ],

  essentialStructures: [
    {
      name: "Bundle of nerve fibers",
      identificationTips: [
        "Look for organized parallel arrays of black myelin tubes running longitudinally through the section",
        "Fascicles appear as distinct bundles surrounded by tan perineurial sheath",
        "Each bundle contains hundreds to thousands of individual myelinated fibers in longitudinal orientation"
      ],
      commonMistakes: [
        {
          mistake: "Confusing individual fibers with entire fascicles",
          why: "Scale confusion - one fascicle contains many fibers",
          avoid: "Identify the perineurium boundary first - everything inside is ONE fascicle containing many individual fibers"
        },
        {
          mistake: "Missing fascicle organization in low magnification",
          why: "Individual fibers blend together at low power",
          avoid: "Start at low power to identify perineurial borders separating fascicles, then zoom in"
        }
      ]
    },
    {
      name: "Negative image of axon (unstained)",
      identificationTips: [
        "Pale/white longitudinal fiber running through center of each black myelin tube",
        "Appears as unstained central core because osmium doesn't stain proteins effectively",
        "Continuous along fiber length except interrupted at nodes of Ranvier",
        "Much thinner than surrounding myelin sheath (typical ratio 1:10 axon:myelin diameter)"
      ],
      commonMistakes: [
        {
          mistake: "Thinking the white axon is extracellular space",
          why: "In OsO₄, axon appears negative/unstained creating confusion",
          avoid: "Remember: OsO₄ stains LIPIDS black but leaves proteins pale - axon is protein-rich cytoplasm"
        },
        {
          mistake: "Confusing axon with node of Ranvier",
          why: "Both appear pale/unstained",
          avoid: "Axon is continuous central core; node is INTERRUPTION where myelin stops completely"
        }
      ]
    },
    {
      name: "Myelin sheath",
      identificationTips: [
        "BLACK/dark brown segmented tubes surrounding axons - the most prominent feature",
        "Appears as interrupted cylinders with regular white gaps (nodes)",
        "Each segment between nodes is called an internode (~1mm long in humans)",
        "Uniform thickness around each axon (except at nodes)",
        "Multiple layers of compacted Schwann cell membrane visible at high magnification"
      ],
      commonMistakes: [
        {
          mistake: "Confusing myelin with adipocytes (both black)",
          why: "Both contain lipids that stain with osmium",
          avoid: "LOCATION: Myelin INSIDE fascicles in organized tubes; adipocytes OUTSIDE in epineurium, large and scattered"
        },
        {
          mistake: "Expecting continuous myelin without interruptions",
          why: "Forgetting about nodes of Ranvier",
          avoid: "Myelin is SEGMENTED - white gaps (nodes) are normal and essential for function"
        },
        {
          mistake: "Missing Schmidt-Lanterman clefts",
          why: "Subtle oblique pale lines within dark myelin",
          avoid: "Look carefully at high magnification for diagonal light lines within myelin segments"
        }
      ]
    },
    {
      name: "Node of Ranvier",
      identificationTips: [
        "WHITE GAPS interrupting black myelin tubes at regular intervals along longitudinal axis",
        "Appear as constrictions where myelin sheath terminates on both sides",
        "Exposed axolemma visible as pale continuation of axon through the gap",
        "Regular spacing (~0.2-2mm depending on fiber diameter)",
        "THE diagnostic feature distinguishing longitudinal from cross-sections"
      ],
      commonMistakes: [
        {
          mistake: "Thinking nodes are artifacts or tissue damage",
          why: "The gaps look like breaks in the tissue",
          avoid: "Nodes are FUNCTIONAL structures - their regularity and bilateral symmetry prove they're real anatomy"
        },
        {
          mistake: "Missing nodes in cross-sections",
          why: "Expecting to see nodes in Slide 72",
          avoid: "Nodes are ONLY visible in LONGITUDINAL sections (Slide 73) - you can't see them in cross-section"
        },
        {
          mistake: "Confusing nodes with Schmidt-Lanterman clefts",
          why: "Both are pale interruptions in myelin",
          avoid: "Nodes = COMPLETE gaps (white space across entire width); Clefts = oblique PARTIAL lines within myelin"
        }
      ]
    },
    {
      name: "Endoneurium",
      identificationTips: [
        "Barely visible pale tan tissue immediately surrounding individual myelin tubes",
        "Contains tiny capillaries running alongside nerve fibers",
        "Best seen in areas where nerve fibers are slightly separated",
        "More prominent in teased fiber preparations than in routine sections"
      ],
      commonMistakes: [
        {
          mistake: "Not identifying endoneurium separately from perineurium",
          why: "Both appear as pale connective tissue",
          avoid: "Endoneurium is INSIDE fascicles around individual fibers; perineurium is AROUND entire fascicle"
        },
        {
          mistake: "Thinking all space between fibers is empty",
          why: "Endoneurium is delicate and subtle",
          avoid: "The space between individual myelin tubes contains endoneurium with vessels and fibroblasts"
        }
      ]
    },
    {
      name: "Perineurium",
      identificationTips: [
        "Distinct multi-layered tan/light brown rim surrounding each fascicle",
        "Appears as 5-10 concentric lamellae at high magnification",
        "Creates clear boundary separating fascicles from epineurium",
        "Most prominent connective tissue layer in longitudinal sections"
      ],
      commonMistakes: [
        {
          mistake: "Counting perineurium as part of epineurium",
          why: "Both are outside the nerve fibers",
          avoid: "Perineurium is SPECIFIC lamellated barrier around fascicles; epineurium is GENERAL loose CT between fascicles"
        },
        {
          mistake: "Missing the blood-nerve barrier function",
          why: "Looks like simple connective tissue",
          avoid: "Perineurium has tight junctions - it's a FUNCTIONAL barrier, not just structural support"
        }
      ]
    },
    {
      name: "Epineurium",
      identificationTips: [
        "Thick tan outer layer surrounding entire nerve and filling spaces between fascicles",
        "Contains prominent BLACK adipocytes scattered throughout",
        "Houses large blood vessels (vasa nervorum) visible as hollow spaces or blood-filled channels",
        "Least organized connective tissue layer with collagen bundles running in various directions"
      ],
      commonMistakes: [
        {
          mistake: "Confusing epineurial adipocytes with myelin",
          why: "Both stain black with osmium",
          avoid: "Adipocytes are LARGE (50-150μm), SPHERICAL, in EPINEURIUM; myelin is small (15μm), TUBULAR, INSIDE fascicles"
        },
        {
          mistake: "Missing vasa nervorum",
          why: "Focusing only on nerve fibers",
          avoid: "Look in epineurium for blood vessels - they're essential for nerve nutrition"
        }
      ]
    },
    {
      name: "Adipocytes",
      identificationTips: [
        "Large BLACK spherical cells scattered in epineurium (50-150μm diameter)",
        "Nucleus pushed to periphery by large lipid droplet (signet ring appearance)",
        "Much larger than myelin tubes and randomly distributed, not organized",
        "Located exclusively in EPINEURIUM, never inside fascicles"
      ],
      commonMistakes: [
        {
          mistake: "Confusing with myelin sheaths",
          why: "Both stain intensely black with osmium",
          avoid: "SIZE and LOCATION: Adipocytes 10× larger than myelin, outside fascicles vs inside"
        },
        {
          mistake: "Thinking adipocytes are pathological",
          why: "They look very prominent in osmium stain",
          avoid: "Adipocytes are NORMAL components of epineurium providing cushioning and energy storage"
        }
      ]
    }
  ],

  keyIdentifyingFeatures: [
    "BLACK segmented myelin tubes running longitudinally through fascicles - positive image with osmium",
    "WHITE GAPS (nodes of Ranvier) interrupting black myelin at regular intervals - THE pathognomonic feature",
    "Pale/unstained axons running through center of black myelin tubes - negative image of protein-rich axoplasm",
    "Three distinct connective tissue layers: thin endoneurium, lamellated perineurium, thick epineurium with black fat",
    "Longitudinal orientation with parallel fiber arrays - distinguishes from cross-sectional view (Slide 72)"
  ],

  identificationTips: [
    "FIRST: Look for longitudinal orientation - parallel fibers running through the section, not circular profiles",
    "SECOND: Identify nodes of Ranvier - white gaps in black myelin tubes prove this is longitudinal OsO₄",
    "THIRD: Confirm BLACK myelin (not white) - this confirms osmium stain, not HE",
    "Start at low power to identify fascicles separated by epineurium, then zoom to see individual fibers",
    "Trace a single black myelin tube along its length - you should see regular white gaps (nodes)",
    "Don't confuse large black adipocytes in epineurium with smaller black myelin tubes in fascicles",
    "Look for Schmidt-Lanterman clefts (oblique pale lines) within myelin segments at high magnification",
    "The perineurium appears as a distinct multi-layered tan border around each fascicle",
    "If you see circular profiles instead of longitudinal tubes, you're on Slide 72 (cross-section), not 73"
  ],

  comparisonWithOtherStains: [
    {
      stain: "HE (Hematoxylin & Eosin)",
      differences: [
        "HE: Myelin appears WHITE (negative image) due to lipid dissolution during processing",
        "OsO₄: Myelin appears BLACK (positive image) because osmium preserves and stains lipids",
        "HE: Axon appears PINK (eosinophilic cytoplasm)",
        "OsO₄: Axon appears PALE/unstained (proteins don't bind osmium)",
        "HE: Nodes of Ranvier difficult to visualize",
        "OsO₄: Nodes dramatically visible as white gaps",
        "HE: Creates 'honeycomb' pattern in cross-sections with white circles",
        "OsO₄: Creates segmented black tubes pattern in longitudinal sections"
      ],
      whenToUse: "Use HE for routine nerve examination and 3-layer identification. Use OsO₄ specifically for studying myelination quality, nodes of Ranvier, and diagnosing demyelinating diseases."
    },
    {
      stain: "Silver stain (Ag)",
      differences: [
        "Silver: Stains AXONS and nerve fibers black (neurofibrils)",
        "OsO₄: Stains MYELIN black (lipids)",
        "Silver: Best for seeing axon continuity and branching patterns",
        "OsO₄: Best for seeing myelin segmentation and nodes",
        "Silver: Unmyelinated fibers visible",
        "OsO₄: Only myelinated fibers prominent",
        "Silver: Commonly used for nerve endings (e.g., Meissner's corpuscle)",
        "OsO₄: Used for myelin disorders and nerve conduction studies"
      ],
      whenToUse: "Use silver stain for tracing nerve pathways and identifying nerve endings. Use OsO₄ for assessing myelination status."
    }
  ],

  commonMistakes: [
    {
      mistake: "Confusing Slide 73 (longitudinal OsO₄) with Slide 72 (cross-section OsO₄)",
      why: "Both use osmium stain so both have black myelin",
      correction: "Look for NODES OF RANVIER (white gaps) - only visible in longitudinal sections (Slide 73). Cross-sections show circular profiles without nodes.",
      examTip: "Nodes = longitudinal. Circles = cross-section. This is THE distinguishing feature!"
    },
    {
      mistake: "Thinking black myelin indicates HE staining",
      why: "Mental mix-up of staining appearances",
      correction: "BLACK myelin = OsO₄ (lipids preserved). WHITE spaces for myelin = HE (lipids dissolved). Remember: OsO₄ = black, HE = white honeycomb.",
      examTip: "If myelin is dark/black, you're looking at osmium. If myelin appears as white spaces, it's HE stain."
    },
    {
      mistake: "Confusing adipocytes with myelin sheaths",
      why: "Both stain intensely black with osmium",
      correction: "LOCATION and SIZE: Adipocytes are LARGE (50-150μm), OUTSIDE fascicles in EPINEURIUM. Myelin is SMALL (15μm), INSIDE fascicles as tubes.",
      examTip: "Ask: Is it inside or outside the fascicle? Inside = myelin, Outside = fat. Also: myelin is organized tubes, fat is scattered spheres."
    },
    {
      mistake: "Missing or misidentifying nodes of Ranvier",
      why: "Thinking the white gaps are artifacts or damage",
      correction: "Nodes are REAL FUNCTIONAL structures with regular spacing. They're essential for saltatory conduction and are the most important feature of longitudinal sections.",
      examTip: "Regular white gaps in black myelin = nodes. If spacing is irregular, may be pathology or poor preparation."
    },
    {
      mistake: "Not distinguishing the three CT layers",
      why: "All appear as pale connective tissue",
      correction: "ENDO = thinnest, around individual fibers inside fascicles. PERI = distinct multi-layered rim around fascicles (blood-nerve barrier!). EPI = thickest, outside fascicles with fat and vessels.",
      examTip: "Perineurium is your anchor - find the distinct lamellated rim first, then endo is inside, epi is outside."
    },
    {
      mistake: "Expecting to see cell bodies or ganglia",
      why: "Confusing peripheral nerve with sensory ganglion",
      correction: "This is NERVE TRUNK only - you see axons, myelin, Schwann cells, CT layers. NO neuronal cell bodies. Those are in ganglia (Slide 74) or CNS.",
      examTip: "Nerve trunk = processes only (axons). Ganglion = cell bodies. Don't confuse them!"
    }
  ],

  clinicalCorrelations: [
    {
      condition: "Multiple Sclerosis (MS) vs Guillain-Barré Syndrome (GBS)",
      relevance: "MS affects CNS myelin; GBS affects PERIPHERAL nerve myelin (like in this slide)",
      details: "In GBS, immune system attacks peripheral nerve myelin → nodes of Ranvier exposed → saltatory conduction fails → ascending paralysis. OsO₄ staining would show myelin loss, irregular node spacing, or complete demyelination in affected nerves."
    },
    {
      condition: "Diabetic Neuropathy",
      relevance: "Chronic hyperglycemia damages peripheral nerves via multiple mechanisms",
      details: "Leads to myelin degeneration, axon loss, and endoneurial microangiopathy. In advanced cases, OsO₄ staining shows decreased myelin density, axon degeneration, and thickened endoneurial blood vessel walls. Nodes may show abnormal spacing or complete loss."
    },
    {
      condition: "Wallerian Degeneration",
      relevance: "Standard pattern of nerve fiber degeneration distal to injury site",
      details: "After nerve transection: 1) Axon fragments, 2) Myelin breaks down (Schwann cells phagocytose debris), 3) Endoneurium persists as scaffold. OsO₄ staining shows fragmented black myelin, loss of node regularity, and eventual clearing of myelin from endoneurium. Used to date injuries forensically."
    },
    {
      condition: "Charcot-Marie-Tooth Disease (CMT)",
      relevance: "Inherited peripheral neuropathy affecting myelin (CMT1) or axons (CMT2)",
      details: "CMT1: Schwann cells produce abnormal myelin → 'onion bulb' formations visible histologically. OsO₄ shows irregular myelin thickness, redundant Schwann cell processes wrapping around axons, and variable node spacing. Slowly progressive weakness and sensory loss."
    }
  ],

  functionalContext: "Peripheral nerves transmit motor commands from CNS to muscles and sensory information from receptors to CNS. The segmented myelin sheath with nodes of Ranvier enables SALTATORY CONDUCTION - action potentials 'jump' from node to node, increasing conduction velocity 50-fold (up to 120 m/s in large myelinated fibers vs 2 m/s in unmyelinated). The three connective tissue layers provide mechanical protection, vascular supply via vasa nervorum, and the critical blood-nerve barrier (perineurium) that maintains the ionic microenvironment necessary for proper axon function. Longitudinal sections like this are essential for studying nerve regeneration, assessing demyelinating diseases, and understanding nerve conduction physiology.",

  examTips: [
    "NODES OF RANVIER are your instant giveaway - only visible in longitudinal OsO₄ sections (Slide 73, not 72)",
    "Memory aid: 'OsO₄ = BLACK myelin, HE = WHITE spaces' - never confuse these!",
    "To distinguish myelin from adipocytes (both black): Ask 'Inside or outside fascicle?' Inside = myelin, Outside = fat",
    "The three CT layers match CNS meninges: Endo=Pia, Peri=Arachnoid, Epi=Dura (memorize this equivalency!)",
    "Perineurium = blood-nerve barrier (has tight junctions) - functionally equivalent to blood-brain barrier",
    "If asked about conduction velocity: Nodes enable saltatory conduction = 50× faster than unmyelinated",
    "Schmidt-Lanterman clefts are a bonus detail - oblique pale lines within myelin segments (cytoplasmic channels)",
    "Clinical correlation: GBS attacks peripheral myelin → nodes disrupted → paralysis. MS attacks CNS myelin",
    "The longitudinal vs cross-section distinction is HEAVILY tested - nodes visible = longitudinal (Slide 73)",
    "Don't forget: Axon appears PALE/unstained in OsO₄ (negative image) vs PINK in HE (positive image)"
  ],

  ultraMinimalFacts: {
    staining: "OsO₄: Myelin = BLACK (lipids stained), Axon = WHITE (unstained proteins)",
    layers: [
      "• ENDO = around 1 fiber (Pia)",
      "• PERI = around fascicle (Arachnoid) - barrier!",
      "• EPI = around nerve (Dura) - has fat"
    ],
    visualID: [
      "• BLACK segmented tubes = myelin (longitudinal)",
      "• WHITE gaps in tubes = nodes of Ranvier",
      "• Large BLACK spheres outside = adipocytes",
      "• Tan multi-layered rim = perineurium"
    ],
    cnsConnection: "Endo→Peri→Epi = Pia→Arachnoid→Dura. Peri = blood-nerve barrier!",
    dontConfuse: [
      "• Longitudinal (73, nodes visible) ≠ Cross (72, circles)",
      "• Myelin (small, inside fascicle) ≠ Fat (large, in epineurium)",
      "• OsO₄ myelin (black) ≠ HE myelin (white spaces)"
    ]
  }
};
// ============================================================================
// TO ADD A NEW SLIDE: Paste generated code (const SLIDE_DATA_XX = {...};) above this line
// Then add the slide number below: XX: SLIDE_DATA_XX,
// ============================================================================

// Collection of all available slides
const SLIDES = {
  70: SLIDE_DATA_70,
  71: SLIDE_DATA_71,
  72: SLIDE_DATA_72,
  73: SLIDE_DATA_73,
  // Add new slides here: 72: SLIDE_DATA_72,
};

// Version Selector Component
const VersionSelector = ({ currentVersion, onVersionChange, versions }) => (
  <div className="flex flex-wrap gap-2 mb-6">
    {versions.map((version) => (
      <button
        key={version.id}
        onClick={() => onVersionChange(version.id)}
        className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
          currentVersion === version.id
            ? 'bg-blue-600 text-white shadow-lg'
            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
        }`}
      >
        {version.icon}
        <span className="font-medium">{version.name}</span>
      </button>
    ))}
  </div>
);

// ============================================================================
// FORMAT 1: HIERARCHICAL
// Best for: Initial learning, comprehensive review
// ============================================================================
const HierarchicalFormat = ({ data }) => (
  <div className="space-y-6">
    <div className="bg-green-50 border-l-4 border-green-500 p-4">
      <p className="text-sm font-semibold text-green-800">📚 HIERARCHICAL: Comprehensive learning format</p>
    </div>

    {/* Staining Info */}
    <div className="bg-gradient-to-r from-purple-50 to-purple-100 border-2 border-purple-300 rounded-lg p-5">
      <h3 className="text-xl font-bold text-purple-900 mb-3">🔬 STAINING: {data.stainingInfo.technique}</h3>
      <p className="text-purple-800 mb-3">{data.stainingInfo.description}</p>
      <div className="bg-white rounded p-3 space-y-1 text-sm">
        <div className="font-bold text-purple-900 mb-2">In THIS slide:</div>
        {data.stainingInfo.whatItStainsInThisSlide.map((item, idx) => (
          <div key={idx} className="text-purple-700">• {item}</div>
        ))}
      </div>
      <div className="mt-3 p-3 bg-purple-200 rounded-lg">
        <div className="font-bold text-purple-900">KEY:</div>
        <div className="text-purple-800 text-sm">{data.stainingInfo.keyEmphasis}</div>
      </div>
    </div>

    {/* Layers (if present) */}
    {data.layers && data.layers.length > 0 && (
      <div className="bg-white border-2 border-gray-300 rounded-lg p-6 shadow-lg">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">📋 LAYERS</h2>
        <div className="space-y-4">
          {data.layers.map((layer, idx) => {
            const colors = ['pink', 'orange', 'green', 'blue', 'purple', 'indigo'];
            const color = colors[idx % colors.length];
            return (
              <div key={idx} className={`border-l-4 border-${color}-400 pl-4 py-3 bg-${color}-50`}>
                <h3 className={`text-lg font-bold text-${color}-700 mb-2`}>
                  {idx + 1}. {layer.name.toUpperCase()}
                </h3>
                <div className="ml-6 space-y-1 text-sm">
                  <div><strong>Level:</strong> {layer.level}</div>
                  {layer.wraps && <div><strong>Wraps:</strong> {layer.wraps}</div>}
                  <div><strong>Appearance:</strong> {layer.appearance}</div>
                  <div><strong>Contains:</strong> {layer.contains}</div>
                  {layer.cnsEquivalent && (
                    <div className="pt-2 border-t mt-2">
                      <strong className="text-blue-700">🧠 CNS:</strong> {layer.cnsEquivalent}
                    </div>
                  )}
                  <div><strong>Quick ID:</strong> {layer.quickID}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    )}

    {/* Big Picture */}
    {data.bigPicture && (
      <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-xl p-6 shadow-lg">
        <div className="flex items-center gap-3 mb-4">
          <Target className="w-8 h-8" />
          <h2 className="text-2xl font-black">BIG PICTURE</h2>
        </div>
        <p className="text-xl mb-4 font-medium">{data.bigPicture}</p>
        {data.hierarchy && (
          <div className="bg-white text-blue-600 rounded-lg p-4">
            {data.hierarchy.map((line, idx) => (
              <div key={idx} className="font-mono text-base">{line}</div>
            ))}
          </div>
        )}
      </div>
    )}

    {/* Inside The Fascicles */}
    {data.insideTheFascicles && data.insideTheFascicles.length > 0 && (
      <div className="bg-white border-2 border-gray-300 rounded-xl p-6 shadow-md">
        <h3 className="text-xl font-bold text-gray-800 mb-4">🔍 INSIDE THE FASCICLES</h3>
        <div className="space-y-3">
          {data.insideTheFascicles.map((item, idx) => (
            <div key={idx} className="bg-gray-50 rounded-lg p-4">
              <div className="font-bold text-blue-700 mb-1">{item.structure}:</div>
              <div className="text-gray-700">{item.description}</div>
            </div>
          ))}
        </div>
      </div>
    )}

    {/* Critical Relationships */}
    {data.criticalRelationships && data.criticalRelationships.length > 0 && (
      <div className="bg-yellow-50 border-2 border-yellow-400 rounded-lg p-6">
        <h3 className="font-bold text-yellow-900 mb-3 text-xl">⚡ CRITICAL RELATIONSHIPS</h3>
        <div className="space-y-4">
          {data.criticalRelationships.map((rel, idx) => (
            <div key={idx} className="bg-white rounded p-4">
              <div className="font-bold text-yellow-900 mb-2">{rel.title}</div>
              <div className="text-yellow-800 text-sm mb-2">{rel.content}</div>
              <div className="ml-4 space-y-1 text-sm text-yellow-700">
                {rel.details.map((detail, i) => (
                  <div key={i}>• {detail}</div>
                ))}
              </div>
              {rel.emphasis && (
                <div className="mt-2 p-2 bg-yellow-100 rounded text-sm font-semibold text-yellow-900">
                  💡 {rel.emphasis}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    )}
  </div>
);

// ============================================================================
// FORMAT 2: QUICK CARDS
// Best for: Fast review, pattern recognition
// ============================================================================
const QuickCardsFormat = ({ data }) => (
  <div className="space-y-6">
    <div className="bg-yellow-50 border-l-4 border-yellow-500 p-4">
      <p className="text-sm font-semibold text-yellow-800">⚡ QUICK CARDS: Flash card style for rapid memorization</p>
    </div>

    {/* Staining Card */}
    {data.stainingInfo && (
      <div className="bg-gradient-to-br from-purple-500 to-purple-600 text-white rounded-xl p-6 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-2xl font-black">STAINING: {data.stain}</h3>
          <span className="text-4xl">🔬</span>
        </div>
        <div className="bg-white/20 rounded-lg p-4 mb-3">
          <div className="text-lg font-bold mb-2">KEY POINT:</div>
          <div className="text-xl">{data.stainingInfo.keyEmphasis}</div>
        </div>
        <div className="text-sm">{data.stainingInfo.description}</div>
      </div>
    )}

    {/* Layer Cards */}
    {data.layers && data.layers.length > 0 && (
      <div className="space-y-4">
        {data.layers.map((layer, idx) => {
          const gradients = [
            { from: 'from-pink-500', to: 'to-pink-600', emoji: '🌸' },
            { from: 'from-orange-500', to: 'to-orange-600', emoji: '📦' },
            { from: 'from-green-500', to: 'to-green-600', emoji: '🛡️' }
          ];
          const gradient = gradients[idx % gradients.length];
          
          return (
            <div key={idx} className={`bg-gradient-to-br ${gradient.from} ${gradient.to} text-white rounded-xl p-6 shadow-lg`}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-2xl font-black">{layer.name.toUpperCase()}</h3>
                <span className="text-4xl">{gradient.emoji}</span>
              </div>
              
              <div className="space-y-3">
                <div className="bg-white/20 rounded-lg p-3">
                  <div className="font-bold text-sm mb-1">WRAPS:</div>
                  <div>{layer.wraps}</div>
                </div>
                
                <div className="bg-white/20 rounded-lg p-3">
                  <div className="font-bold text-sm mb-1">LOOKS LIKE:</div>
                  <div>{layer.appearance}</div>
                </div>
                
                <div className="bg-white/20 rounded-lg p-3">
                  <div className="font-bold text-sm mb-1">KEY FEATURE:</div>
                  <div>{layer.composition}</div>
                </div>
                
                {layer.cnsEquivalent && (
                  <div className="bg-white/30 rounded-lg p-3">
                    <div className="font-bold text-sm mb-1">CNS =</div>
                    <div>{layer.cnsEquivalent}</div>
                  </div>
                )}
              </div>
              
              <div className="mt-4 bg-white text-gray-800 rounded-lg p-3 font-bold text-sm">
                🎯 SPOT IT: {layer.quickID}
              </div>
            </div>
          );
        })}
      </div>
    )}
  </div>
);

// ============================================================================
// FORMAT 3: RELATIONSHIPS
// Best for: Understanding connections, spatial reasoning
// ============================================================================
const RelationshipsFormat = ({ data }) => (
  <div className="space-y-6">
    <div className="bg-blue-50 border-l-4 border-blue-500 p-4">
      <p className="text-sm font-semibold text-blue-800">🔗 RELATIONSHIPS: Connection-focused format</p>
    </div>

    {/* Staining Context */}
    <div className="bg-purple-50 border-l-4 border-purple-500 p-4">
      <h3 className="font-bold text-purple-900 mb-2">STAINING CONTEXT</h3>
      <p className="text-purple-800 text-sm">
        <strong>{data.stain} staining:</strong> {data.stainingInfo?.keyEmphasis || data.bigPicture}
      </p>
    </div>

    {/* Nested Structure (Cross-section View) */}
    <div className="bg-white border-2 border-gray-300 rounded-lg p-6 shadow-lg">
      <h2 className="text-2xl font-bold text-center mb-6">NESTED STRUCTURE (Cross-section View)</h2>
      <div className="flex justify-center">
        {/* Outermost: Epineurium */}
        <div className="bg-green-100 border-4 border-green-600 rounded-3xl p-8 w-full max-w-xl">
          <div className="text-center font-bold text-green-800 mb-4">
            EPINEURIUM (Dura equivalent)
          </div>
          
          {/* Middle: Perineurium */}
          <div className="bg-orange-100 border-4 border-orange-500 rounded-2xl p-6">
            <div className="text-center font-bold text-orange-800 mb-4">
              PERINEURIUM (Arachnoid equivalent)
            </div>
            
            {/* Inner: Endoneurium */}
            <div className="bg-pink-100 border-4 border-pink-500 rounded-xl p-5">
              <div className="text-center font-bold text-pink-800 mb-3">
                ENDONEURIUM (Pia equivalent)
              </div>
              
              {/* Innermost: Nerve Fiber */}
              <div className="bg-blue-200 border-2 border-blue-600 rounded-lg p-4">
                <div className="text-center font-bold text-blue-900 mb-2">NERVE FIBER</div>
                <div className="text-center text-blue-800 text-sm">
                  Axon (pink) + Myelin (white) + Schwann cell
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    {/* Relationship Matrix */}
    {data.layers && data.layers.length > 0 && (
      <div className="bg-white border-2 border-gray-300 rounded-lg p-6 shadow-lg">
        <h2 className="text-2xl font-bold mb-4">RELATIONSHIP MATRIX</h2>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="bg-gray-200">
                <th className="border border-gray-400 p-3 text-left">Layer</th>
                <th className="border border-gray-400 p-3 text-left">Level</th>
                <th className="border border-gray-400 p-3 text-left">Appearance</th>
                {data.layers[0].cnsEquivalent && (
                  <th className="border border-gray-400 p-3 text-left">CNS Equivalent</th>
                )}
              </tr>
            </thead>
            <tbody>
              {data.layers.map((layer, idx) => {
                const bgColors = ['bg-pink-50', 'bg-orange-50', 'bg-green-50', 'bg-blue-50'];
                return (
                  <tr key={idx} className={bgColors[idx % bgColors.length]}>
                    <td className="border border-gray-400 p-3 font-bold">{layer.name}</td>
                    <td className="border border-gray-400 p-3">{layer.level}</td>
                    <td className="border border-gray-400 p-3">{layer.appearance}</td>
                    {data.layers[0].cnsEquivalent && (
                      <td className="border border-gray-400 p-3">{layer.cnsEquivalent || 'N/A'}</td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    )}

    {/* Size Comparison */}
    <div className="bg-white border-2 border-gray-300 rounded-lg p-6 shadow-lg">
      <h2 className="text-2xl font-bold mb-4">SIZE COMPARISON (Critical for ID!)</h2>
      <div className="space-y-4">
        {/* Axon */}
        <div className="flex items-center gap-4">
          <div className="flex-shrink-0">
            <div className="w-3 h-3 rounded-full bg-pink-500 border-2 border-pink-700"></div>
          </div>
          <div className="text-sm">
            <span className="font-bold">Axon:</span> Tiny pink dot (diameter 1-5 μm)
          </div>
        </div>
        
        {/* Myelin space */}
        <div className="flex items-center gap-4">
          <div className="flex-shrink-0">
            <div className="w-8 h-8 rounded-full border-4 border-blue-500 bg-white"></div>
          </div>
          <div className="text-sm">
            <span className="font-bold">Myelin space:</span> Tiny white circular halo
          </div>
        </div>
        
        {/* Adipocyte */}
        <div className="flex items-center gap-4">
          <div className="flex-shrink-0">
            <div className="w-16 h-16 rounded-full border-4 border-yellow-500 bg-yellow-50"></div>
          </div>
          <div className="text-sm">
            <span className="font-bold">Adipocyte:</span> HUGE (up to many times bigger)
          </div>
        </div>
      </div>
      
      <div className="mt-4 bg-red-50 border-l-4 border-red-500 p-3">
        <p className="text-red-800 text-sm font-semibold">
          ⚠️ COMMON MISTAKE: Confusing adipocytes with myelin - 3× and EPINEURIUM, not fascicle!
        </p>
      </div>
    </div>

    {/* Relationships Summary - Concise Reworked Version */}
    {data.relationshipsSummary && data.relationshipsSummary.length > 0 && (
      <div className="bg-blue-50 border-2 border-blue-400 rounded-lg p-6">
        <h3 className="font-bold text-blue-900 mb-3 text-xl">🔑 CRITICAL RELATIONSHIPS</h3>
        <div className="space-y-3">
          {data.relationshipsSummary.map((rel, idx) => (
            <div key={idx} className="bg-white rounded p-4 shadow">
              <div className="font-bold text-blue-900 mb-2">{rel.title}</div>
              <div className="text-blue-800 text-sm mb-2 italic">{rel.summary}</div>
              {rel.keyPoints && rel.keyPoints.map((point, i) => (
                <div key={i} className="text-blue-700 text-sm ml-4">• {point}</div>
              ))}
            </div>
          ))}
        </div>
      </div>
    )}
  </div>
);

// ============================================================================
// FORMAT 4: ULTRA-MINIMAL
// Best for: Last-minute cramming, time pressure
// ============================================================================
const UltraMinimalFormat = ({ data }) => {
  const umf = data.ultraMinimalFacts || {};
  
  return (
    <div className="space-y-6">
      <div className="bg-red-50 border-l-4 border-red-500 p-4">
        <p className="text-sm font-semibold text-red-800">🎯 ULTRA-MINIMAL: Only must-know facts</p>
      </div>

      {/* Must-Know Facts */}
      <div className="bg-gradient-to-br from-red-500 to-red-600 text-white rounded-2xl p-8 shadow-2xl">
        <div className="text-center mb-6">
          <h2 className="text-3xl font-black">⚠️ MUST-KNOW FACTS</h2>
        </div>
        
        <div className="space-y-4">
          {/* 1. STAINING */}
          {umf.staining && (
            <div className="bg-white/20 rounded-lg p-5">
              <div className="flex items-center gap-3 mb-3">
                <span className="bg-white text-red-600 w-8 h-8 rounded-full flex items-center justify-center font-black">
                  1
                </span>
                <h3 className="text-xl font-bold">STAINING</h3>
              </div>
              <div className="ml-11 text-lg">{umf.staining}</div>
            </div>
          )}

          {/* 2. THE LAYERS */}
          {umf.layers && umf.layers.length > 0 && (
            <div className="bg-white/20 rounded-lg p-5">
              <div className="flex items-center gap-3 mb-3">
                <span className="bg-white text-red-600 w-8 h-8 rounded-full flex items-center justify-center font-black">
                  2
                </span>
                <h3 className="text-xl font-bold">THE LAYERS</h3>
              </div>
              <div className="ml-11 space-y-2">
                {umf.layers.map((layer, idx) => (
                  <div key={idx} className="text-base">{layer}</div>
                ))}
              </div>
            </div>
          )}

          {/* 3. VISUAL ID */}
          {umf.visualID && umf.visualID.length > 0 && (
            <div className="bg-white/20 rounded-lg p-5">
              <div className="flex items-center gap-3 mb-3">
                <span className="bg-white text-red-600 w-8 h-8 rounded-full flex items-center justify-center font-black">
                  3
                </span>
                <h3 className="text-xl font-bold">VISUAL ID</h3>
              </div>
              <div className="ml-11 space-y-2">
                {umf.visualID.map((item, idx) => (
                  <div key={idx} className="text-base">{item}</div>
                ))}
              </div>
            </div>
          )}

          {/* 4. CNS CONNECTION */}
          {umf.cnsConnection && (
            <div className="bg-white/20 rounded-lg p-5">
              <div className="flex items-center gap-3 mb-3">
                <span className="bg-white text-red-600 w-8 h-8 rounded-full flex items-center justify-center font-black">
                  4
                </span>
                <h3 className="text-xl font-bold">CNS CONNECTION</h3>
              </div>
              <div className="ml-11 text-lg">{umf.cnsConnection}</div>
            </div>
          )}

          {/* 5. DON'T CONFUSE */}
          {umf.dontConfuse && umf.dontConfuse.length > 0 && (
            <div className="bg-white/20 rounded-lg p-5">
              <div className="flex items-center gap-3 mb-3">
                <span className="bg-white text-red-600 w-8 h-8 rounded-full flex items-center justify-center font-black">
                  5
                </span>
                <h3 className="text-xl font-bold">DON'T CONFUSE</h3>
              </div>
              <div className="ml-11 space-y-2">
                {umf.dontConfuse.map((item, idx) => (
                  <div key={idx} className="text-base">{item}</div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

    {/* One-Sentence Summaries */}
    {data.layers && data.layers.length > 0 && (
      <div className="bg-yellow-50 border-4 border-yellow-400 rounded-xl p-6">
        <h3 className="font-black text-yellow-900 mb-4 text-2xl text-center">ONE-SENTENCE SUMMARIES</h3>
        <div className="space-y-3 text-lg">
          {data.layers.map((layer, idx) => {
            const colors = ['pink', 'orange', 'green', 'blue'];
            return (
              <div key={idx} className="flex gap-3">
                <span className={`font-black text-${colors[idx % colors.length]}-600 min-w-fit`}>
                  {layer.name.toUpperCase()}:
                </span>
                <span>{layer.quickID}</span>
              </div>
            );
          })}
        </div>
      </div>
    )}

    {/* 30-Second Drill */}
    <div className="bg-black text-white rounded-xl p-6">
      <h3 className="font-black mb-4 text-2xl text-center">⏱️ 30-SECOND DRILL</h3>
      <div className="space-y-2 font-mono text-sm">
        {data.layers && data.layers.map((layer, idx) => (
          <div key={idx}>
            <div>Q: What does {layer.name} do?</div>
            <div className="text-blue-400 ml-4 mb-2">A: {layer.function}</div>
          </div>
        ))}
      </div>
    </div>
    </div>
  );
};

// ============================================================================
// NAVIGATION COMPONENT
// ============================================================================
const SlideNavigation = ({ currentSlide, onSlideChange, totalSlides = 100 }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);

  const handleSearch = (e) => {
    e.preventDefault();
    const slideNum = parseInt(searchQuery);
    if (slideNum >= 1 && slideNum <= totalSlides) {
      onSlideChange(slideNum);
      setSearchQuery('');
      setShowDropdown(false);
    }
  };

  const handlePrevious = () => {
    if (currentSlide > 1) {
      onSlideChange(currentSlide - 1);
    }
  };

  const handleNext = () => {
    if (currentSlide < totalSlides) {
      onSlideChange(currentSlide + 1);
    }
  };

  return (
    <div className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-3 py-2">
        <div className="flex items-center gap-2">
          {/* Previous Button */}
          <button
            onClick={handlePrevious}
            disabled={currentSlide <= 1}
            className="p-2 rounded-lg hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            title="Previous slide"
          >
            <ChevronLeft size={20} className="text-gray-700" />
          </button>

          {/* Slide Selector Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowDropdown(!showDropdown)}
              className="px-3 py-2 bg-blue-50 text-blue-700 rounded-lg font-semibold text-sm hover:bg-blue-100 transition-colors whitespace-nowrap"
            >
              Slide {currentSlide}
            </button>
            {showDropdown && (
              <div className="absolute top-full left-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg w-48 max-h-64 overflow-y-auto z-50">
                <div className="p-2 border-b border-gray-100 text-xs text-gray-500 font-semibold">
                  Select Slide (1-{totalSlides})
                </div>
                {[...Array(totalSlides)].map((_, i) => (
                  <button
                    key={i + 1}
                    onClick={() => {
                      onSlideChange(i + 1);
                      setShowDropdown(false);
                    }}
                    className={`w-full text-left px-3 py-2 text-sm hover:bg-blue-50 transition-colors ${
                      currentSlide === i + 1 ? 'bg-blue-100 text-blue-700 font-semibold' : 'text-gray-700'
                    }`}
                  >
                    Slide {i + 1}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Search Bar */}
          <form onSubmit={handleSearch} className="flex-1 flex items-center gap-1">
            <div className="relative flex-1 max-w-xs">
              <Search size={16} className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Go to slide #"
                className="w-full pl-8 pr-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <button
              type="submit"
              className="px-3 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap"
            >
              Go
            </button>
          </form>

          {/* Next Button */}
          <button
            onClick={handleNext}
            disabled={currentSlide >= totalSlides}
            className="p-2 rounded-lg hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            title="Next slide"
          >
            <ChevronRight size={20} className="text-gray-700" />
          </button>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// MAIN APP COMPONENT
// ============================================================================
const App = () => {
  const [currentVersion, setCurrentVersion] = useState('hierarchical');
  const [currentSlideNumber, setCurrentSlideNumber] = useState(70);
  
  // Get current slide data dynamically based on navigation
  const SLIDE_DATA = SLIDES[currentSlideNumber] || SLIDES[70];

  const versions = [
    { 
      id: 'hierarchical', 
      name: 'Hierarchical', 
      icon: <Layers size={20} />,
      component: HierarchicalFormat 
    },
    { 
      id: 'quick', 
      name: 'Quick Cards', 
      icon: <Zap size={20} />,
      component: QuickCardsFormat 
    },
    { 
      id: 'relationship', 
      name: 'Relationships', 
      icon: <Network size={20} />,
      component: RelationshipsFormat 
    },
    { 
      id: 'minimal', 
      name: 'Ultra-Minimal', 
      icon: <Target size={20} />,
      component: UltraMinimalFormat 
    }
  ];

  const CurrentComponent = versions.find(v => v.id === currentVersion)?.component;

  // Handle slide navigation - dynamically loads slide data from SLIDES object
  const handleSlideChange = (slideNum) => {
    if (SLIDES[slideNum]) {
      setCurrentSlideNumber(slideNum);
      console.log(`Navigated to slide ${slideNum}`);
    } else {
      console.warn(`Slide ${slideNum} not available yet`);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      {/* Navigation Bar */}
      <SlideNavigation 
        currentSlide={currentSlideNumber} 
        onSlideChange={handleSlideChange}
        totalSlides={100}
      />

      {/* Main Content */}
      <div className="max-w-6xl mx-auto p-4">
        {/* Header */}
        <div className="bg-white rounded-2xl shadow-xl p-6 mb-6">
          <h1 className="text-4xl font-black text-gray-800 mb-2">
            Lara's Histology Study App
          </h1>
          <p className="text-gray-600 text-lg">
  <strong>Slide {SLIDE_DATA.slideNumber}:</strong> {SLIDE_DATA.name}
  {SLIDE_DATA.section && ` - ${SLIDE_DATA.section}`} ({SLIDE_DATA.stain})
</p>
          <p className="text-sm text-gray-500 mt-2">
            4 study formats for different learning needs
          </p>
        </div>

        {/* Version Selector */}
        <VersionSelector 
          currentVersion={currentVersion}
          onVersionChange={setCurrentVersion}
          versions={versions}
        />

        {/* Content Area */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          {CurrentComponent && <CurrentComponent data={SLIDE_DATA} />}
        </div>

        {/* Footer */}
        <div className="mt-6 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl p-6 shadow-lg">
          <h3 className="font-bold text-xl mb-3">📝 STUDY STRATEGY</h3>
          <div className="grid md:grid-cols-2 gap-4 text-sm">
            <div>
              <div className="font-bold mb-2">Learning Phase:</div>
              <div>1. Start with Hierarchical</div>
              <div>2. Move to Relationships</div>
              <div>3. Practice with Quick Cards</div>
              <div>4. Final review: Ultra-Minimal</div>
            </div>
            <div>
              <div className="font-bold mb-2">Time Management:</div>
              <div>• First study: Hierarchical (30 min)</div>
              <div>• Quick review: Quick Cards (10 min)</div>
              <div>• Before exam: Ultra-Minimal (5 min)</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
