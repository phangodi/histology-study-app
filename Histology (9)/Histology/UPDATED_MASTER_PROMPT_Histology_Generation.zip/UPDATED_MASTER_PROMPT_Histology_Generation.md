# MASTER PROMPT: Histology Slide Content Generation v3.0
**Updated for 4-format study app with specific styling requirements**

## 📋 OBJECTIVE
Generate a complete JavaScript object for a histology slide with comprehensive exam-ready content optimized for 4 different study formats: Hierarchical, Quick Cards, Relationships, and Ultra-Minimal.

## ⚠️ IMPORTANT: CHARACTER LIMITS POLICY

### ❌ STRICT CHARACTER LIMITS (Cramming sections ONLY):
**Character limits apply ONLY to these ultra-concise sections:**
- `ultraMinimalFacts.staining` (80 chars)
- `ultraMinimalFacts.layers` (50 chars per bullet)
- `ultraMinimalFacts.visualID` (60 chars per bullet)
- `ultraMinimalFacts.cnsConnection` (70 chars)
- `ultraMinimalFacts.dontConfuse` (70 chars per bullet)
- `relationshipsSummary.summary` (150 chars)
- `relationshipsSummary.keyPoints` (80 chars per point)
- `bigPicture` (100 chars)

**Why?** These are last-minute cramming tools that MUST be ultra-concise for quick review.

### ✅ NO CHARACTER LIMITS (Comprehensive learning sections):
**These sections should be COMPLETE and DETAILED - write as much as medically necessary:**
- `layers` - Full descriptions (composition, appearance, function, etc.)
- `criticalRelationships` - Comprehensive with full details arrays (4-6+ items)
- `stainingInfo.keyEmphasis` - Complete staining explanations
- `stainingInfo.whatItStainsInThisSlide` - All necessary items
- `keyIdentifyingFeatures` - Thorough feature descriptions
- `commonMistakes` - Full explanations with corrections
- `clinicalCorrelations` - Comprehensive clinical relevance
- `identificationTips` - Detailed guidance
- `examTips` - Complete exam strategies
- `essentialStructures` - Detailed structure descriptions

**Why?** Medical education cannot sacrifice critical content. Students need complete, accurate information for comprehensive learning. Complex slides (multiple layers, cell types, regions) REQUIRE detailed descriptions.

### 🎯 GOLDEN RULE:
**"Ultra-Minimal = Concise (for cramming). Everything else = Complete (for learning)."**

**DO NOT worry about length in comprehensive sections!** If a layer needs 3 sentences to explain properly, write 3 sentences. If criticalRelationships needs 8 detail points to be medically accurate, include all 8. Medical accuracy > arbitrary limits.

---

## 🚨🚨🚨 CRITICAL WARNING - READ BEFORE GENERATING! 🚨🚨🚨

### **`criticalRelationships` FIELD IS ABSOLUTELY MANDATORY!**

**This field displays as yellow boxes labeled "⚡ CRITICAL RELATIONSHIPS (EXAM FAVORITES!)" in the UI**

**CRITICAL IMPORTANCE:**
- **MOST HIGH-YIELD** content for medical board exams
- Students depend on this for exam success
- Missing this field **BREAKS** Hierarchical and Relationships views
- **NON-NEGOTIABLE** for medical education accuracy and consistency

**MINIMUM REQUIREMENTS:**
- **At least 3-4 relationship sections** per slide (no exceptions!)
- Each section MUST have:
  - `title`: Include (HIGH-YIELD!) or (EXAM FAVORITE!) tag
  - `content`: 1-2 sentence explanation
  - `details`: Array of 4-6 specific facts
  - `emphasis`: Why this is critical for exams

**TYPICAL RELATIONSHIPS (include all applicable):**
1. CNS-PNS transitions (for nervous tissue)
2. Size comparisons (when similar structures exist)
3. Hierarchical/wrapping patterns
4. Blood-barrier information
5. Functional connections
6. Clinical correlations

**❌ DO NOT generate any slide without criticalRelationships!**
**✅ CHECK TWICE before outputting - is criticalRelationships present with 3-4 sections?**

---

## 🎯 INSTRUCTIONS FOR CLAUDE

### STEP 1: Read the Automation Guide
**First action:** Read `UPDATED_HISTOLOGY_AUTOMATION_GUIDE.md` to understand the complete schema and all format-specific requirements.

### STEP 2: Identify the Slide
Search the MTO PDF (`School_s_essential_list_that_includes_all_the_slides_and_essential_structures_on_the_MTO_.pdf`) for the requested slide number to extract:
- Full slide name
- Stain type
- ALL listed structures (including sub-structures with hyphens)

### STEP 3: Find Relevant Documents
Use `OFFICIAL_MTO_DIRECTORY.md` to identify which PDF files contain information about this slide.

### STEP 4: Research Content
1. Search the identified PDF files for detailed information
2. **CRITICAL:** Use general histology knowledge to supplement if documents are incomplete
3. Ensure all mandatory elements are included (see checklist below)

### STEP 5: Generate Complete Object
Create a complete JavaScript object following the exact schema in the Automation Guide.

---

## ⚠️ MANDATORY INCLUSIONS (Check every time!)

### ✅ For EVERY Slide:
- [ ] **Complete staining information** (technique, mechanism, what it stains in THIS slide, key emphasis)
- [ ] **bigPicture** - One concise sentence summarizing the slide
- [ ] **hierarchy** - Array of 3 strings with arrows (→ and ↓) showing structural organization
- [ ] **insideTheFascicles** (for nerve slides) or equivalent detail section
- [ ] **🚨 CRITICAL RELATIONSHIPS - MINIMUM 3-4 SECTIONS (NEVER SKIP THIS!)** 
- [ ] **🔑 RELATIONSHIPS SUMMARY - CONCISE VERSION FOR RELATIONSHIPS VIEW (MANDATORY!)**
- [ ] **keyIdentifyingFeatures** - 4-5 pathognomonic features
- [ ] **comparisonWithOtherStains** (if multiple stains available)
- [ ] **commonMistakes** - 4-5 common errors with corrections
- [ ] **Ultra-minimal must-know facts** (5 concise sections)

### ✅ For Slides with LAYERS:
- [ ] **ALL layers included in `layers` array** (not in essentialStructures)
- [ ] Each layer has: name, level, wraps, composition, appearance, contains, function, quickID
- [ ] For nerve slides: Include CNS equivalent for each layer

### ✅ For Nervous System Slides:
- [ ] **CNS equivalents included** (Endoneurium=Pia, Perineurium=Arachnoid, Epineurium=Dura)
- [ ] Blood-nerve barrier information (if peripheral nerve)
- [ ] Gray vs white matter distinction (if CNS)
- [ ] Hierarchy arrows showing layer transitions

### ✅ For Slides with Size Distinctions:
- [ ] **Size comparisons** with specific measurements when available
- [ ] Visual size indicators (e.g., "3× larger")
- [ ] Clear differentiation in identification tips

---

## 📊 NEW STRUCTURE REQUIREMENTS

### 1. BIG PICTURE (MANDATORY)
**Field:** `bigPicture` (string)
- One concise sentence (under 100 characters)
- Summarizes the slide's main concept
- **Example:** "Peripheral nerve = axons wrapped in 3 protective CT layers (like CNS meninges!)"

### 2. HIERARCHY (MANDATORY)
**Field:** `hierarchy` (array of exactly 3 strings)
- Shows structural organization with arrows
- Use → for horizontal progression, ↓ for vertical transition
- **Format:**
  ```javascript
  hierarchy: [
    "Axon → Fascicle → Whole Nerve",
    "↓ ENDO → PERI → EPI",
    "↓ (Pia) → (Arachnoid) → (Dura)"
  ]
  ```
- Line 1: Main structural progression
- Line 2: Layer abbreviations with downward arrow
- Line 3: CNS equivalents (if applicable) with downward arrow

### 3. INSIDE THE FASCICLES (For nerve slides)
**Field:** `insideTheFascicles` (array of objects)
- Lists 4-5 key structures visible inside fascicles
- Each object has: `structure` (name), `description` (brief explanation)
- **Example:**
  ```javascript
  insideTheFascicles: [
    {
      structure: "Axon",
      description: "Tiny pink dot in center of myelin ring; carries electrical impulses"
    },
    {
      structure: "Myelin sheath (negative image)",
      description: "White circular space around axon; lipid dissolved during processing creating honeycomb pattern"
    }
  ]
  ```

### 4. ULTRA-MINIMAL MUST-KNOW FACTS
**Field:** `ultraMinimalFacts` (object with 5 sections)
- **CRITICAL:** These must be CONCISE bullet points, not full sentences
- Section 1: STAINING (1-2 key points)
- Section 2: THE LAYERS (bullet list with = format)
- Section 3: VISUAL ID (4-5 quick visual cues)
- Section 4: CNS CONNECTION or KEY RELATIONSHIPS (exam-focused)
- Section 5: DON'T CONFUSE (common mix-ups)

**Format:**
```javascript
ultraMinimalFacts: {
  staining: "HE: Myelin = WHITE (lipids dissolved!), not pink. Honeycomb = diagnostic",
  layers: [
    "• ENDO = wraps 1 fiber (Pia)",
    "• PERI = wraps bundle (Arachnoid) - blood-nerve barrier!",
    "• EPI = wraps nerve (Dura)"
  ],
  visualID: [
    "• Honeycomb inside fascicles = myelin (white circles)",
    "• Dark nuclei at edge of rings = Schwann cells",
    "• Distinct pink rim around bundles = perineurium",
    "• Large white outside fascicles = adipocytes"
  ],
  cnsConnection: "Endo → Peri → Epi = Pia → Arachnoid → Dura (transition at nerve roots)",
  dontConfuse: [
    "• Myelin (small, inside fascicles) ≠ Adipocyte (large, in epineurium)",
    "• Schwann nucleus (edge of ring) ≠ Axon (center dot)",
    "• HE myelin (white) ≠ OsO₄ myelin (black)"
  ]
}
```

---

## 🎨 FORMAT-SPECIFIC CONTENT GUIDELINES

### HIERARCHICAL FORMAT
**Displays:** Big Picture → Inside The Fascicles → Staining → Layers → Critical Relationships

**Requirements:**
- Big Picture shows in blue gradient box with Target icon
- Hierarchy displays in white box with blue monospace text
- Inside The Fascicles shows after Layers section
- All layers must have complete details
- Critical Relationships show in FULL with all details

### QUICK CARDS FORMAT
**Displays:** Gradient-colored flashcards with white text

**Requirements for each layer card:**
- **Color assignments:** pink (Endoneurium), orange (Perineurium), green (Epineurium)
- **Sections needed:**
  - WRAPS: What this layer surrounds
  - LOOKS LIKE: Visual appearance
  - KEY FEATURE: Composition or defining trait
  - CNS: CNS equivalent (if applicable)
  - SPOT IT: Quick ID tip from quickID field

### RELATIONSHIPS FORMAT
**Displays:** Staining Context → Nested Structure → Matrix → Size Comparison → Relationships Summary

**Requirements:**
- Staining context needs concise explanation (1-2 sentences)
- Nested structure shows layers as nested boxes (outermost to innermost)
- Size comparison section needs visual descriptors
- **CRITICAL**: Uses `relationshipsSummary` field (NOT `criticalRelationships`)

### 🔑 RELATIONSHIPS SUMMARY FIELD (MANDATORY!)

**Field:** `relationshipsSummary` (array of objects)

**This is DIFFERENT from `criticalRelationships`!**
- `criticalRelationships`: Verbose, comprehensive (for Hierarchical view in YELLOW boxes)
- `relationshipsSummary`: **Concise, reworked** (for Relationships view in BLUE boxes)

**Format:**
```javascript
relationshipsSummary: [
  {
    title: "CNS-PNS Transition (HIGH-YIELD!)",
    summary: "Endo→Peri→Epi = Pia→Arachnoid→Dura at nerve roots. Direct transition ensures continuous protection.",
    keyPoints: [
      "Transition occurs at nerve root entry/exit zones",
      "Blood-nerve barrier (peri) ↔ Blood-brain barrier (BBB)",
      "Essential for board exams!"
    ]
  },
  // 2-3 more concise relationship summaries
]
```

**Requirements:**
- **2-4 relationship summaries** (fewer than criticalRelationships)
- Each has:
  - `title`: Concise title with (HIGH-YIELD!) tag
  - `summary`: 1-2 sentence overview (under 150 chars)
  - `keyPoints`: Array of 3-4 bullets (under 80 chars each)
- **MUST be rewritten to be more concise** - NOT just copy/paste from criticalRelationships!
- Focus on exam-critical connections only

### ULTRA-MINIMAL FORMAT  
**Displays:** Must-Know Facts with numbered circular badges in RED box

**⚠️ CRITICAL REQUIREMENTS (ENFORCE STRICTLY):**
1. **NO REPETITION** - Do NOT repeat content from other sections!
2. **MAXIMUM 80 characters per line** - Use abbreviations: ENDO/PERI/EPI (not full names)
3. **ONE line per bullet** - No multi-line explanations or paragraphs
4. **Use symbols**: = (equals), → (to), ≠ (not equal), vs. (versus)
5. **Cramming focus** - Only must-know facts to pass exam in 60 seconds

**5 Required Sections:**
- **staining**: ONE sentence under 80 chars - diagnostic feature only
- **layers**: 3 bullets MAX - "• NAME = function (CNS)" under 50 chars each
- **visualID**: 4-5 bullets - "• Feature = meaning" under 60 chars (NO repetition from layers!)
- **cnsConnection**: ONE line under 70 chars with arrows
- **dontConfuse**: 3-4 bullets with ≠ symbol, under 70 chars each

---

## 🔍 COMPLETE EXAMPLE: Peripheral Nerve

```javascript
{
  slideNumber: "70",
  name: "Peripheral Nerve (HE)",
  section: "cross section",
  stain: "HE",
  
  // NEW: Big Picture
  bigPicture: "Peripheral nerve = axons wrapped in 3 protective CT layers (like CNS meninges!)",
  
  // NEW: Hierarchy with arrows
  hierarchy: [
    "Axon → Fascicle → Whole Nerve",
    "↓ ENDO → PERI → EPI",
    "↓ (Pia) → (Arachnoid) → (Dura)"
  ],
  
  // NEW: Inside The Fascicles
  insideTheFascicles: [
    {
      structure: "Axon",
      description: "Tiny pink dot in center of myelin ring; carries electrical impulses"
    },
    {
      structure: "Myelin sheath (negative image)",
      description: "White circular space around axon; lipid dissolved during processing creating honeycomb pattern"
    },
    {
      structure: "Schwann cell nucleus",
      description: "Elongated blue nucleus at periphery of myelin ring; produces and maintains myelin"
    },
    {
      structure: "Endoneurium",
      description: "Delicate pink CT between individual fibers; contains capillaries"
    }
  ],
  
  stainingInfo: {
    technique: "H&E (Hematoxylin and Eosin)",
    description: "Hematoxylin stains basophilic structures (nuclei, ribosomes, rough ER) blue/purple. Eosin stains acidophilic structures (cytoplasm, collagen, muscle fibers) pink/red.",
    whatItStainsInThisSlide: [
      "Nuclei (Schwann cells, fibroblasts, endothelial cells) → Blue/purple",
      "Connective tissue (endoneurium, perineurium, epineurium) → Pink",
      "Axon cytoplasm → Pale pink (when visible)",
      "Myelin sheath → WHITE SPACE (negative image - lipids dissolved during tissue processing)",
      "Adipocyte cytoplasm → WHITE SPACE (lipids removed)"
    ],
    keyEmphasis: "HE emphasizes the three-layered connective tissue organization and cellular nuclei. The characteristic honeycomb pattern created by myelin spaces (white circles) within fascicles is the signature feature. Lipid dissolution during histological preparation creates negative images of both myelin sheaths and adipocytes."
  },

  layers: [
    {
      name: "Endoneurium",
      level: "Innermost layer (Level 1)",
      wraps: "Individual nerve fiber (single axon + myelin sheath + Schwann cell)",
      composition: "Delicate loose connective tissue with reticular fibers (Type III collagen), scattered fibroblasts, and capillaries",
      appearance: "Very thin pink tissue barely visible between individual nerve fibers within a fascicle. Seen as delicate pink strands separating the white myelin spaces.",
      contains: "Endoneurial capillaries (part of blood-nerve barrier), fibroblasts, reticular fibers, tissue fluid",
      cnsEquivalent: "Pia mater (direct transition at CNS-PNS junction at nerve roots)",
      function: "Provides microenvironment for individual nerve fibers, supports axon nutrition and metabolic exchange, maintains ionic balance",
      quickID: "Thinnest pink layer, barely visible between individual fibers inside bundles"
    },
    {
      name: "Perineurium",
      level: "Middle layer (Level 2)",
      wraps: "Fascicle (bundle of multiple nerve fibers)",
      composition: "2-6 concentric layers of specialized epithelioid perineural cells (modified fibroblasts) connected by tight junctions, each layer surrounded by basement membrane",
      appearance: "Distinct pink rim encircling each fascicle, appearing as a smooth, continuous boundary. More prominent than endoneurium, creates clear fascicle borders.",
      contains: "Perineural cells with tight junctions, basement membrane, occasional fibroblasts, perineurial space",
      cnsEquivalent: "Arachnoid mater (transition at nerve roots)",
      function: "Forms blood-nerve barrier controlling diffusion of substances into/out of fascicle, maintains stable microenvironment for nerve conduction, protects against mechanical stress",
      quickID: "Pink rim surrounding each honeycomb bundle - the fascicle border"
    },
    {
      name: "Epineurium",
      level: "Outermost layer (Level 3)",
      wraps: "Entire nerve (multiple fascicles together)",
      composition: "Dense irregular connective tissue with thick collagen bundles, adipose tissue, fibroblasts, blood vessels (vasa nervorum), and lymphatics",
      appearance: "Thick pink connective tissue surrounding and separating fascicles. Contains large white adipocytes and blood vessels. Forms the outermost coat of the nerve.",
      contains: "Large blood vessels (vasa nervorum), lymphatics, adipose tissue, nervi nervorum (nerves innervating nerve sheaths), thick collagen bundles",
      cnsEquivalent: "Dura mater (continuous transition at nerve roots)",
      function: "Mechanical protection of nerve, provides vascular supply, allows nerve mobility, cushioning between fascicles",
      quickID: "Thickest pink layer with adipocytes, surrounds entire nerve and fills spaces between fascicles"
    }
  ],

  essentialStructures: [
    {
      name: "Bundle of Nerve Fibers (Fascicle)",
      definition: "Organized group of multiple myelinated axons bundled together and completely encircled by perineurium",
      location: "Multiple circular to oval bundles scattered throughout the nerve cross-section, each separated by epineurium",
      appearance: "Circular to oval structure with characteristic honeycomb pattern - white circular spaces (myelin) with tiny pink centers (axons) and blue nuclei (Schwann cells) at periphery",
      function: "Organizes nerve fibers into functional groups for efficient transmission; protects and isolates fiber bundles",
      identificationTips: [
        "Look for honeycomb pattern of white circles - this is THE signature feature",
        "Each bundle completely surrounded by distinct pink perineurium rim",
        "Multiple bundles of varying sizes within one nerve",
        "White spaces (myelin) are small and uniform within fascicles",
        "Perineurium appears as smooth, continuous pink boundary"
      ],
      commonMistakes: [
        {
          mistake: "Confusing a single myelin ring with an entire fascicle",
          why: "Both are circular structures",
          avoid: "Fascicle contains MANY myelin rings (honeycomb); single fiber is just one ring"
        },
        {
          mistake: "Missing the perineurium boundary",
          why: "Can be subtle in some sections",
          avoid: "Always look for the distinct pink rim around each bundle - this defines the fascicle"
        }
      ]
    }
  ],

  relatedStructures: [
    {
      name: "Blood Vessels (Vasa Nervorum)",
      description: "Small arterioles and capillaries supplying the nerve. Found in epineurium and penetrating into endoneurium."
    },
    {
      name: "Adipocytes",
      description: "Large fat cells appearing as white spaces in epineurium. Much larger than myelin spaces and located OUTSIDE fascicles."
    }
  ],

  // 🚨🚨🚨 CRITICAL RELATIONSHIPS - MANDATORY SECTION! 🚨🚨🚨
  // This section is REQUIRED for every slide - minimum 3-4 relationship sections
  // These appear as yellow boxes in the UI labeled "⚡ CRITICAL RELATIONSHIPS (EXAM FAVORITES!)"
  criticalRelationships: [
    {
      title: "CNS-PNS Transition Zone (HIGH YIELD EXAM TOPIC!)",
      content: "At the nerve roots where peripheral nerves enter/exit the CNS, the three connective tissue layers transition directly to the three meningeal layers:",
      details: [
        "Endoneurium → Pia mater (innermost, delicate)",
        "Perineurium → Arachnoid mater (middle, barrier function)",
        "Epineurium → Dura mater (outermost, tough protection)",
        "Transition occurs at CNS-PNS junction",
        "Blood-nerve barrier (perineurium) continuous with blood-brain barrier (BBB)"
      ],
      emphasis: "This parallel 3-layer protective system is ESSENTIAL to understand for exams. The continuity ensures protected nerve roots!"
    },
    {
      title: "Size Comparison: Myelin Spaces vs Adipocytes (CRITICAL DISTINCTION!)",
      content: "Both myelin sheaths and adipocytes appear as white spaces in HE sections, but they are easily distinguished:",
      details: [
        "MYELIN: Small (5-15 μm), uniform circles inside fascicles, create honeycomb pattern",
        "ADIPOCYTES: Large (50-150 μm, 3× bigger), variable sizes, located in EPINEURIUM outside fascicles",
        "MYELIN: Has Schwann nucleus at periphery and axon in center",
        "ADIPOCYTES: Has nucleus pushed to edge, no central structure",
        "LOCATION is key: Myelin = inside bundles, Adipocytes = between bundles"
      ],
      emphasis: "SIZE and LOCATION are the two critical features. If confused, ask: Is it inside or outside the fascicle?"
    },
    {
      title: "Hierarchical Organization (Wrapping Pattern)",
      content: "Understanding the nesting order is essential for identification:",
      details: [
        "Level 1: Single axon wrapped by ENDONEURIUM",
        "Level 2: Bundle of axons (fascicle) wrapped by PERINEURIUM",
        "Level 3: Bundle of fascicles (whole nerve) wrapped by EPINEURIUM",
        "Each layer provides progressively stronger protection",
        "Compare to: Wire → Cable → Bundled cables"
      ],
      emphasis: "This hierarchical pattern is your roadmap for nerve identification!"
    }
  ],

  identificationTips: [
    "Start by finding fascicles - look for honeycomb pattern (white circles with pink centers)",
    "Identify the 3 CT layers from inside out: Endo (thin, barely visible) → Peri (pink rim) → Epi (thick, with fat)",
    "White spaces INSIDE bundles = myelin; white spaces OUTSIDE bundles = adipocytes",
    "Remember the mnemonic 'EPA' for outer to inner: Epineurium (thickest, adipocytes) → Perineurium (rim, barrier) → Axons (with endoneurium)",
    "Use the myelinated fiber pattern: honeycomb + distinct rim + thick coat = peripheral nerve!",
    "If you see BLACK myelin instead of white spaces, you're looking at OsO₄ stain (Slide 72), not HE!",
    "The perineurium is your anchor structure - once you find those pink rims around bundles, everything else falls into place"
  ],
  
  // NEW: Ultra-Minimal Must-Know Facts (CONCISE!)
  ultraMinimalFacts: {
    staining: "HE: Myelin = WHITE (lipids dissolved!), not pink. Honeycomb = diagnostic",
    layers: [
      "• ENDO = wraps 1 fiber (Pia)",
      "• PERI = wraps bundle (Arachnoid) - blood-nerve barrier!",
      "• EPI = wraps nerve (Dura)"
    ],
    visualID: [
      "• Honeycomb inside fascicles = myelin (white circles)",
      "• Dark nuclei at edge of rings = Schwann cells",
      "• Distinct pink rim around bundles = perineurium",
      "• Large white outside fascicles = adipocytes"
    ],
    cnsConnection: "Endo → Peri → Epi = Pia → Arachnoid → Dura (transition at nerve roots)",
    dontConfuse: [
      "• Myelin (small, inside fascicles) ≠ Adipocyte (large, in epineurium)",
      "• Schwann nucleus (edge of ring) ≠ Axon (center dot)",
      "• HE myelin (white) ≠ OsO₄ myelin (black)"
    ]
  }
}
```

---

## 🚨 CRITICAL REQUIREMENTS FOR ULTRA-MINIMAL FACTS

### Must be CONCISE - Not Full Sentences!
**❌ WRONG (too wordy):**
```javascript
ultraMinimalFacts: {
  staining: "Hematoxylin and Eosin staining technique emphasizes the three-layered connective tissue organization and cellular nuclei throughout the peripheral nerve preparation."
}
```

**✅ CORRECT (concise):**
```javascript
ultraMinimalFacts: {
  staining: "HE: Myelin = WHITE (lipids dissolved!), not pink. Honeycomb = diagnostic"
}
```

### Use Bullet Format with =

**Peripheral Nerve:**
```javascript
hierarchy: [
  "Axon → Fascicle → Whole Nerve",
  "↓ ENDO → PERI → EPI",
  "↓ (Pia) → (Arachnoid) → (Dura)"
]
```

**Skin:**
```javascript
hierarchy: [
  "Epidermis → Dermis → Hypodermis",
  "↓ 5 layers → 2 layers → Adipose",
  "↓ Basale → Spinosum → Granulosum → Lucidum → Corneum"
]
```

**CNS (Brain):**
```javascript
hierarchy: [
  "Meninges → Gray Matter → White Matter",
  "↓ Dura → Arachnoid → Pia",
  "↓ Neurons → Myelinated tracts"
]
```

---

## 🔧 QUICK CARDS REQUIREMENTS

### Each layer needs these EXACT fields:
- `wraps`: What this layer surrounds (e.g., "Individual nerve fiber")
- `appearance`: Visual description (e.g., "Distinct pink rim encircling each fascicle")
- `composition`: What it's made of (e.g., "Dense irregular CT with collagen")
- `cnsEquivalent`: CNS equivalent if applicable (e.g., "Pia mater")
- `quickID`: One-sentence quick tip (e.g., "Thinnest pink layer inside bundles")

### Color assignments for nerve slides:
- Endoneurium → Pink card
- Perineurium → Orange card
- Epineurium → Green card

---

## 🚨 PRE-OUTPUT VALIDATION CHECKLIST (VERIFY EVERY ITEM!)

### MANDATORY FIELDS - VERIFY PRESENT:
1. [ ] `slideNumber`, `name`, `section`, `stain` ✓
2. [ ] `bigPicture` (concise, under 100 chars) ✓
3. [ ] `hierarchy` (exactly 3 strings with → and ↓) ✓
4. [ ] `insideTheFascicles` or equivalent detail section ✓
5. [ ] `stainingInfo` (complete with keyEmphasis) ✓
6. [ ] `layers` (ALL layers if applicable) ✓
7. [ ] **🚨 `criticalRelationships` (MINIMUM 3-4 sections) - CHECK TWICE!** ✓
8. [ ] `keyIdentifyingFeatures` (4-5 features) ✓
9. [ ] `comparisonWithOtherStains` (if applicable) ✓
10. [ ] `commonMistakes` (4-5 mistakes) ✓
11. [ ] `clinicalCorrelations` (3-4 conditions if applicable) ✓
12. [ ] `functionalContext` (if applicable) ✓
13. [ ] `sizeReference` (if applicable) ✓
14. [ ] `examTips` (5-7 tips if applicable) ✓
15. [ ] `ultraMinimalFacts` (all 5 sections in CONCISE format) ✓

### CRITICAL RELATIONSHIPS VALIDATION:
- [ ] Has AT LEAST 3 relationship sections ✓
- [ ] Each has `title`, `content`, `details` (4-6 items), `emphasis` ✓
- [ ] Includes CNS-PNS connections (if nervous tissue) ✓
- [ ] Includes size comparisons (if applicable) ✓
- [ ] Includes hierarchical organization ✓
- [ ] Each title has (HIGH-YIELD!) or (EXAM FAVORITE!) tag ✓

### RELATIONSHIPS SUMMARY VALIDATION:
- [ ] Has 2-4 concise relationship summaries ✓
- [ ] Each has `title`, `summary` (under 150 chars), `keyPoints` (3-4 items) ✓
- [ ] Content is REWRITTEN to be concise (NOT copy/paste from criticalRelationships) ✓
- [ ] Each keyPoint is under 80 characters ✓
- [ ] Focuses on exam-critical connections only ✓
- [ ] Each title has (HIGH-YIELD!) tag ✓

### ULTRA-MINIMAL FACTS VALIDATION:
- [ ] `staining` is ONE sentence under 80 characters ✓
- [ ] `layers` has EXACTLY 3 bullets, each under 50 characters ✓
- [ ] `visualID` has 4-5 bullets, each under 60 characters ✓
- [ ] NO repetition of content from other sections ✓
- [ ] All bullets use abbreviations (ENDO not Endoneurium) ✓
- [ ] `cnsConnection` is ONE line under 70 characters ✓
- [ ] `dontConfuse` has 3-4 bullets with ≠ symbol, each under 70 characters ✓
- [ ] Total reading time is under 60 seconds ✓

### SYNTAX VALIDATION:
- [ ] Valid JavaScript object syntax ✓
- [ ] Double quotes (not single) ✓
- [ ] Proper commas (no trailing commas) ✓
- [ ] Arrays properly formatted ✓
- [ ] Output is ONLY the JavaScript object (no extra text) ✓

---

## 💡 REMEMBER

**The goal is EXAM SUCCESS with optimized study formats.**
- Big Picture provides instant context
- Hierarchy shows organization visually
- Ultra-Minimal Facts must be CONCISE for quick cramming
- All 4 formats use the same data object

**Quality Standards:**
- Every field must have specific, practical content
- No placeholder text
- Use exam-focused language
- Include high-yield information

---

**READY TO GENERATE? Just say: "Generate Slide [NUMBER]"**
